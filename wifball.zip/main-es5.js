function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<router-outlet></router-outlet>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/conditionuse/conditionuse.component.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/conditionuse/conditionuse.component.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppConditionuseConditionuseComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class='container'>\n<br><br>\n<h2>General Conditions of sale and use</h2><br>\n<p>We strive to make your use of our website as smooth as possible. As always, if anything about our terms of use is\nunclear or confusing, please contact us by email.<br>\nThese general conditions of sale and use govern your access and use of https://wifball.com, as well as any content made\navailable from or through this website (the \"Website\").\nThe website is operated by reig guy-charles (the \"company\", \"us\" or \"our\").<br>\nYou accept that by accessing the Site, you have read, understood and agreed to be bound by all these general conditions of sale and use.\nIf you do not agree with all of these general conditions of sale and use, we ask you not to use the website.\nThe information provided on the website is not intended for use by any person or entity in a jurisdiction or\ncountry where such use would be contrary to law or regulation or who would subject us to a registration requirement in\nthat jurisdiction or that country. Consequently, people who choose to access the Site from other locations do so on their\nown initiative and are solely responsible for compliance with local laws, if and to the extent that local laws are applicable.\n</p><br><br>\n\n\n\n<h3>Prohibited activities</h3><br>\n<p>As a user of the Site, you agree not to:</p><br>\n<p>• Download or transmit (or attempt to download or transmit) viruses, Trojans or any other material that modifies,\nalters, disrupts, alters or interferes with the use,\n functionality, functions, operation or maintenance of the website.</p>\n<p>• Disappearance, tarnishing or any other damage, in our opinion, to us and / or to the website.</p>\n<p>• Use the website in a manner incompatible with applicable laws or regulations.</p>\n<p>• Attempt to impersonate another user or another person or use the username of another user.</p>\n<p>• Use the website as part of any effort to compete with us or otherwise use the website and / or content for any income generating\nor commercial enterprise.</p>\n<p>• Decrypt, decompile, disassemble or reverse engineer any software that includes or in any way constitutes part of the website.</p>\n<p>• Attempt to circumvent any measure on the website designed to prevent or restrict access to the website or any part of the website.</p>\n<p>• Harass, annoy, intimidate or threaten any of our employees or agents hired to provide you with part of the website.</p>\n<p>• Remove copyright or other proprietary rights notices from all content.</p>\n<p>• Copy or adapt the software or code from the website.</p>\n<p>• Bypass, disable or otherwise interfere with the security features of the website.</p>\n<p>• Engage in an unauthorized framing or link to the website.</p>\n<p>• Deceive, defraud or mislead us and other users, especially in any attempt to learn sensitive account information such as user passwords.</p>\n<p>• Abuse our support services or submit false reports of abuse or misconduct.</p>\n<p>• Take part in any automated use of the system, for example by using scripts to send comments or messages,\nor by using data mining tools, robots or\nsimilar tools for collecting and extracting data.</p>\n<p>• Interfering, disrupting or creating an undue burden on the website or the networks or services connected to the website.</p>\n<p>• Make any unauthorized use of the website, including the collection of user names and / or email addresses of\nusers by electronic or other means for the purpose of sending unsolicited email, or\ncreating accounts of users by automated means or under false pretenses.</p>\n\n<h2>Products / Services</h2>\n\n<p>All products / Services provided via the website are subject to availability and we cannot guarantee that the\nitems will be in stock, as far as our services are concerned our guarantees are a constant effort for stability\nand flawless accessibility. We reserve the right to discontinue any product / service at any time for any reason.\nThe prices of all products / services are subject to change.</p>\n\n\n<h2>Duration and termination</h2>\n<p>These general conditions of sale and use will remain in force and in full effect while you use the website.\nWithout limiting any other provision of these general conditions of sale and use, we reserve the right, in our sole\ndiscretion and without notice or liability, to refuse access and use of the website (including the blocking of certain\nIP addresses), to any person for any reason whatsoever or without reason, including, without limitation, for violation of any representation,\nguarantee or commitment contained in these general conditions of sale and use or any law or applicable regulations.</p>\n\n\n\n<h2>Payment</h2>\n<p>You agree to provide current, complete and accurate payment and account information for all payments made through the website.\nYou further agree to promptly update account and payment information, including email address,\nmethod of payment and payment card expiration date, so that we can complete your transactions and contact you if necessary.\n We can change prices at any time.</p>\n\n\n<h2>privacy policy</h2>\n<p>We care about privacy and data security. Please see our privacy policy.\nBy using the website, you agree to be bound by our privacy policy, which is incorporated into these general conditions of sale and use.</p>\n\n<h2>Intellectual property rights</h2>\n<p>Unless otherwise noted, the website is our exclusive property and all source codes, databases, features, software,\nwebsite designs, audio, video, text, photographs and graphics on the website (collectively, \"Content\" ) and the trademarks,\nservice marks and logos contained therein (the \"Marks\") are owned by us or controlled by us or licensed, and are protected by\ncopyright and trademarks and various other intellectual property rights. Content and brands are provided on the website \"as is\"\nfor your information and personal use only. Unless expressly provided otherwise in these general conditions of sale and use, no\npart of the Website and no Content or Brands may be copied, reproduced, aggregated, republished, downloaded, published, publicly\ndisplayed, encoded, translated, transmitted, distributed , sold, authorized or otherwise exploited for any commercial purpose without\nour express prior written permission.\nProvided you are able to use the website, you have a limited license to access and use the website and to download or print a copy of\nany portion of the content to which you have correctly accessed only for your personal, non-commercial use . use. We reserve all rights\nnot expressly granted to you in and on the website, content and brands.</p><br>\n\n<h2>interruptions</h2>\n\n<p>We cannot guarantee that the website will be available at all times. We may experience hardware, software or other problems or need\nto perform website related maintenance, resulting in interruptions, delays or errors. We reserve the right to change, revise, update,\nsuspend, discontinue or otherwise modify the website at any time or for any reason without notice.\nYou agree that we have no responsibility for any loss, damage or inconvenience caused by your inability to access or use the website\nduring any interruption or interruption of the website.</p><br>\n\n\n<h2>User data</h2>\n\n<p>We will keep certain data that you transmit to the website for the purpose of managing website performance,\n as well as data relating to your use of the website. Although we make regular and regular backups of the data,\n you are solely responsible for any data that you transmit or that relates to any activity that you have undertaken\n  using the website. You agree that we will have no responsibility to you in the event of loss or corruption of this data,\nand you hereby waive any right of action against us arising from such loss or corruption of this data.</p><br>\n\n<h2>Liability limitations</h2>\n<p>In no event shall we be liable to you or a third party for any direct, indirect, consecutive, exemplary,\nincidental, special or punitive damage resulting from your use of the website, even if we have been informed of the possibility of such damage.\n</p><br>\n<h2>Disclaimer</h2>\n<p>The website is provided as is and subject to availability. To the fullest extent permitted by law, we disclaim all warranties,\nexpress or implied, in connection with the website and your use of it, including, without limitation, the implied warranties\nof merchantability, fitness for particular use and non-infringement. We make no warranty or representation regarding the accuracy\nor completeness of the website content and we will not assume any responsibility for (a) errors, errors or inaccuracies in the content\nand materials, (b) any access not authorized to or the use of our secure servers and / or any personal and / or financial information\nstored there, (c) any interruption or cessation of transmission to or from the website, (d) any bug, virus, Trojan horse or other that\nmay be transmitted to or via the website by a third party, and / or (e) any error or omission in any content and material or for any loss\nor damage of any kind whatsoever resulting from the use any content published, transmitted or otherwise made available through the\nwebsite.</p><br>\n\n\n\n<h2>Compensation</h2>\n<p>You agree to defend, indemnify and protect us from any loss, damage, liability, claim or demand, including reasonable attorneys'\nfees and expenses, made by a third party because of or resulting from: ( a) use of the website; (b) violation of these general conditions\nof sale and use; or (c) any violation of your declarations and guarantees set out in these general conditions of sale and use.\n</p><br>\n<h2>Applicable law</h2>\n<p>These general conditions of sale and use and your use of the Site are governed by and interpreted in accordance with French law,\nwithout regard to its principles of conflict of laws.\nModifications of the general conditions of sale and use\nWe reserve the right, in our sole discretion, to change, modify, add or delete any part of the general conditions of sale and use,\nin whole or in part, at any time. The modifications of the general conditions of sale and use will come into force as of their publication.\nYour continued use of the website and / or the services made available on or through the website after the publication of any\nmodification of the general conditions of sale and use will be considered as acceptance of these modifications.\n</p>\n<br>\n<div class='text-center'><a routerLink=\"/login\">Back</a></div><br><br>\n\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/forget/forget.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/forget/forget.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppForgetForgetComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-loading [condition]=\"!isLoading\"></app-loading>\n<header *ngIf=\"isLoading\">\n    <img src=\"../../assets/Wifball logo.png\" alt=\"\">\n    <h1>discuss football and make the best decisions for your online betting</h1>\n</header>\n<div class=\"row\"*ngIf=\"isLoading\">\n  <div class=\"col-md-6\" style=\"margin-left: auto;margin-right:auto;\">\n<div class=\"container\" style=\"width:60%; \">\n    <div class=\"form-wrap \" *ngIf=\"flag>=0\" >\n        <form [formGroup]=\"loginForm\" (ngSubmit)=\"login()\"style=\"padding-top:15%\">\n            <h1 >Forget</h1>\n          <div class=\"input-wrap\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Email</mat-label>\n              <input matInput type=\"email\" name=\"email\" [formControl]=\"email\" placeholder=\"Email\">\n            </mat-form-field>\n          </div>\n          <div class=\"recaptcha\" style=\"margin:auto;text-align: center;\">\n            <re-captcha (resolved)=\"resolved($event)\" siteKey=\"6LdCXPQUAAAAAC8lgskB60g_DDesYpOdO1IDUZhM\"></re-captcha>\n        </div>\n            <button mat-raised-button type=\"submit\" color=\"primary\" style=\"width: 70%;height:auto;margin-top:30px;padding:10px 10px\">\n            <i class=\"fa fa-paper-plane\"></i> Validate\n          </button>\n          <div>\n            <br>\n            <a routerLink=\"/login\" style=\"text-align: left!important;\">Back</a>\n         </div>\n        </form>\n    </div>\n    <div class=\"form-wrap \" *ngIf=\"flag>=1\"style=\"padding-top:15%\">\n          <h1 >Verification</h1>\n          <div class=\"input-wrap\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Verfify</mat-label>\n              <input matInput type=\"text\" name=\"verfy\"#verify placeholder=\"verify code...\">\n            </mat-form-field>\n          </div>\n            <button mat-raised-button (click)=\"verifyFunc(verify.value)\" color=\"primary\" style=\"width: 70%;height:auto;margin-top:30px;padding:10px 10px\">\n            <i class=\"fa fa-paper-plane\"></i> Check\n          </button>\n          <div>\n            <a routerLink=\"/register\" style=\"text-align: left!important;\">create an account</a>\n         </div>\n    </div>\n    <div class=\"form-wrap \" *ngIf=\"flag>=2\"style=\"padding-top:15%\">\n        <form [formGroup]=\"updateForm\" (ngSubmit)=\"updateFunc()\">\n            <h1 >Reset password</h1>\n          <div class=\"input-wrap\">\n\n            <mat-form-field appearance=\"outline\">\n              <mat-label>New Password</mat-label>\n              <input matInput type=\"password\" name=\"password\" [formControl]=\"password\" placeholder=\"password\">\n            </mat-form-field>\n          </div>\n            <button mat-raised-button type=\"submit\" color=\"primary\" style=\"width: 70%;height:auto;margin-top:30px;padding:10px 10px\">\n            <i class=\"fa fa-paper-plane\"></i> Update\n          </button>\n          <div>\n            <a routerLink=\"/register\" style=\"text-align: left!important;\">create an account</a>\n         </div>\n        </form>\n    </div>\n\n</div>\n</div></div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/legalnotice/legalnotice.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/legalnotice/legalnotice.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLegalnoticeLegalnoticeComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class='container'><br><br>\n<h1>Legal Notice</h1><br><br>\n<p>The information provided on the website is not intended for use by any person or entity in a jurisdiction\nor country where such use would be contrary to law or regulation or who would subject us to a registration\nrequirement in that jurisdiction or that country. Consequently, people who choose to access the Site from other\nlocations do so on their own initiative and are solely responsible for compliance with local laws, if and to the\nextent that local laws are applicable.<br><br>\n\nWe reserve the right to make changes to this legal notice. Any changes we may make to this legal\nnotice will be published on this page and, if applicable, we will also notify you by email.\nCertain provisions of this legal notice may be replaced by legal notices or expressly designated\nterms located on particular pages of the website.<br><br>\n\nYou accept that this legal notice is exclusively governed in accordance with the laws and courts of France.\nNotwithstanding the above, nothing in this legal notice will prevent us from going to court to bring an action\nin violation of our intellectual property rights.</p><br><br>\n\n\n<div class='text-center'><a routerLink=\"/login\">Back</a></div><br><br>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/loading/loading.component.html":
  /*!**************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/loading/loading.component.html ***!
    \**************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoadingLoadingComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"abs-center\" *ngIf=\"condition\">\n    <mat-spinner></mat-spinner>\n  </div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html":
  /*!**********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoginLoginComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div *ngIf='warning' class='warning-div'>{{ warning_message }}<button (click)='closeWarningbutton()' class='warning-button'><i class=\"fa fa-close\" style=\"font-size:17px;color:lightgreen\"></i></button></div>\n<header>\n    <img src=\"../../assets/Wifball logo.png\" alt=\"\">\n    <h1>discuss football and make the best decisions for your online betting</h1>\n    <!-- <h1>DISCUSS FOOTBALL AND MAKE THE BEST DECISIONS FOR YOUR ONLINE BETTING football and make the best decisions for your online betting</h1> -->\n</header>\n<div class=\"row back_3\">\n  <div class=\"col-md-6\" style=\"margin-left: auto;margin-right:auto;\">\n    <div class=\"container\" style=\"width:60%\">\n        <div class=\"form-wrap \" style='min-width: 550px; min-height: 700px;'>\n            <form [formGroup]=\"loginForm\" (ngSubmit)=\"login()\">\n                <h1 >Log In</h1>\n              <div class=\"input-wrap\">\n                <mat-form-field appearance=\"outline\">\n                  <mat-label>Email</mat-label>\n                  <input matInput type=\"email\" name=\"email\" [formControl]=\"email\" placeholder=\"Email\">\n                </mat-form-field>\n              </div>\n              <div class=\"input-wrap\">\n                <mat-form-field appearance=\"outline\">\n                    <mat-label>Password</mat-label>\n                    <input matInput type=\"password\" name=\"password\" [formControl]=\"password\" placeholder=\"Password\" style=\"height: auto;\">\n                </mat-form-field>\n              </div>\n              <!-- <button mat-raised-button type=\"submit\" [disabled]=\"!loginForm.valid\" color=\"primary\" style=\"width: 70%;\"> -->\n              <div>\n                  <a routerLink=\"/forget\" style=\"text-align: left!important;\">forget password</a>\n              </div>\n              <div class=\"recaptcha\" style=\"margin:auto;text-align: center;padding-top:30px\">\n                  <re-captcha (resolved)=\"resolved($event)\" siteKey=\"6LdCXPQUAAAAAC8lgskB60g_DDesYpOdO1IDUZhM\"></re-captcha>\n              </div>\n                <button mat-raised-button type=\"submit\" color=\"primary\"[disabled]=\"!loginForm.valid\"  style=\"width: 70%;height:auto;margin-top:30px;padding:10px 10px\">\n                <i class=\"fa fa-paper-plane\"></i> Connection\n              </button>\n              <div class=\"input-wrap\">\n                  <h4>Start Now only <span style=\"color: rgb(56,103,213);\">2</span> steps left</h4>\n              </div>\n              <p><span>Step1:</span> Register or login</p>\n              <p><span>Step2:</span> Start to discuss football</p>\n              <div>\n                <a routerLink=\"/register\" style=\"text-align: left!important;\">create an account</a>\n              </div>\n            <div class='row'>\n              <div class='col-md-4'><a  routerLink=\"/condition\" style = 'color: green;font-weight:bold;' >CGU/CGV</a></div>\n              <div class='col-md-4 text-center'><a routerLink=\"/privacy\" style = 'color: green;font-weight:bold;' >privacy policy</a></div>\n              <div class='col-md-4'><a  routerLink=\"/legal\" style = 'color: green;font-weight:bold;' >Legal Notice</a></div>\n            </div>\n            </form>\n        </div>\n    </div>\n  </div>\n\n</div>\n\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.component.html":
  /*!********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.component.html ***!
    \********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMainMainComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div>\n<div *ngIf='warning' class='warning-div'>{{ warning_message }}<button (click)='closeWarningbutton()' class='warning-button'><i class=\"fa fa-close\" style=\"font-size:17px;color:lightgreen\"></i></button></div>\n<header class=\"main_header\">\n    <div class='back_white'>\n      <div class='header-div-line'><div class='top-bar-line'></div></div>\n      <div class='select-room'><h3 class='text-center'>SELECT ROOM</h3></div>\n      <div class='header-div-line'><div class='top-bar-line'></div></div>\n    </div>\n    <div style='padding-top:20px;'>\n        <img src=\"/assets/Wifball logo.png\" alt=\"\">\n        <h2 class='text-center text-white'>Discuss Football and make the best decisions For your online bettings</h2>\n    </div>\n    <div class='button-group text-center' [ngSwitch] = \"pageName\">\n      <div *ngSwitchCase=\"'response'\">\n        <button (click) = \"pageChange('subscriber')\" class='subscribers-button'>Posts subscribers</button>\n        <button (click) = \"pageChange('main')\" class='main-chatroom-button'>Main chatroom</button>\n        <button (click) = \"pageChange('response')\" class='received-button active-border'>Responses received</button>\n<button mat-flat-button  color=\"primary\" class=\"darkblue\" (click)=\"logout()\" style='color:white;position:absolute;right:10px;'>DISCONNECT</button>\n      </div>\n      <div *ngSwitchCase=\"'subscriber'\">\n        <button (click) = \"pageChange('subscriber')\" class='subscribers-button active-border'>Posts subscribers</button>\n        <button (click) = \"pageChange('main')\" class='main-chatroom-button'>Main chatroom</button>\n        <button (click) = \"pageChange('response')\" class='received-button'>Responses received</button>\n<button mat-flat-button  color=\"primary\" class=\"darkblue\" (click)=\"logout()\" style='color:white;position:absolute;right:10px;'>DISCONNECT</button>\n      </div>\n      <div *ngSwitchCase=\"'main'\">\n        <button (click) = \"pageChange('subscriber')\" class='subscribers-button'>Posts subscribers</button>\n        <button (click) = \"pageChange('main')\" class='main-chatroom-button active-border'>Main chatroom</button>\n        <button (click) = \"pageChange('response')\" class='received-button'>Responses received</button>\n<button mat-flat-button  color=\"primary\" class=\"darkblue\" (click)=\"logout()\" style='color:white;position:absolute;right:10px;'>DISCONNECT</button>\n      </div>\n      <div *ngSwitchDefault>\n        <button (click) = \"pageChange('subscriber')\" class='subscribers-button'>Posts subscribers</button>\n        <button (click) = \"pageChange('main')\" class='main-chatroom-button'>Main chatroom</button>\n        <button (click) = \"pageChange('response')\" class='received-button'>Responses received</button>\n<button mat-flat-button  color=\"primary\" class=\"darkblue\" (click)=\"logout()\" style='color:white;position:absolute;right:10px;'>DISCONNECT</button>\n      </div>\n\n    </div>\n</header>\n<div class=\"current\">\n    <div class=\"row\" style=''>\n      <div class='col-md-3'>\n        <div class='row'>\n          <div class='col-md-6'>\n            <div style='padding-left: 30px;'>\n              <img [src]=\"imgURL\" class='photo_img'>\n              <h2 style=\"color:white;font-size:16px;padding-top: 8px;padding-left: 30px;\">{{currentUser.msg.pseduo}}</h2>\n            </div>\n          </div>\n          <div class='col-md-6 text-white' *ngIf='currentUser.msg.img_state==1'>\n            profile picture:            <input #imgInput  type=\"file\" onclick=\"this.value=null\" (change)=\"preview(imgInput.files)\"  name=\"photo\" ng2FileSelect [uploader]=\"uploader\" style='height:15px; color:white;font-size:8px;margin-bottom:6px;'/>\n            <button class=\"upload_button\" (click)=\"uploader.uploadAll()\" [disabled]=\"!uploader.getNotUploadedItems().length\" >UPLOAD</button>\n          </div>\n          <div class='col-md-6 text-white' *ngIf='currentUser.msg.img_state==0'>\n            profile picture: <br><br>\n            <button class=\"upload_button\" (click)=\"blockwarning()\">UPLOAD</button>\n          </div>\n        </div>\n      </div>\n      <div class='col-md-7'>\n        <div class='row'>\n          <div class='col-md-4'>\n            <br>\n            <div style=\"color:white;font-size:16px\">\n             Number of subscribers:\n              <div class=\"text-center counter-div\" style='color:#0e5b60'>{{ subscribers }}</div>\n            </div>\n          </div>\n          <div class='col-md-4'>\n            <br>\n            <div style=\"color:white;font-size:16px\">\n              Number of responses received:\n              <div class=\"text-center counter-div\" style='color:green;'>{{ resonse_received }}</div>\n            </div>\n          </div>\n          <div class='col-md-4 text-center' style=\"color:white;font-size:16px\">\n            Remaing days:\n            <div class=\"text-center remaing-day-div\" style='color:orange'>{{ remaining_days }}</div>\n            <button class='subscription-button' (click)=\"pageChange('getSub')\">Subscription</button>\n          </div>\n        </div>\n      </div>\n      <div class='col-md-2'>\n\t      <div class='text-center' style='color:white;font-size: 16px;'>Number of online users</div>\n        <div class='text-center' style='margin-top:5px;margin-bottom:10px;'><div class='text-center' style='color:white;width:70%;background-color: green;padding: 7px;margin:auto;border-radius:8px;'>{{onlineusers}}</div></div>\n      </div>\n    </div>\n    <div class = 'row' *ngIf = 'cur_status' style = 'background-color: #007bff; padding:10px;'>\n      <div class=\"col-md-1 text-center\">\n                  <br>\n                    <span *ngIf=\"cur_photoUrl==null then image1 else image2\">\n                      <img src=\"/assets/image/login.jpg\" class='sub-photo-img'>\n                    </span>\n                    <ng-template #image1><img src=\"/assets/image/login.jpg\" class='sub-photo-img'></ng-template>\n                    <ng-template #image2><img src=\"http://192.162.69.178:3000/images/{{ cur_photoUrl }}\" class='sub-photo-img'></ng-template>\n                    <p style=\"color:white;margin-top: 8px;\">{{ cur_name }}</p>\n                </div>\n                <div class=\"col-md-9\">\n                    <div style='width:100%; max-height: 80px; overflow-y: scroll; border-radius:8px;background-color:white;padding:5px;'><pre>{{ cur_message }}</pre></div>\n                    <span *ngIf='cur_videoLink==null || cur_videoLink==\"\" then link1 else link2'>\n\n                    </span>\n\n                      <ng-template #link1>\n                         <p style=\"color:white;margin-top: 8px;\">Video link:\n                        <button value='{{ cur_videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> No link </button>\n                        <button class='discover-button'>discover</button></p>\n                      </ng-template>\n                      <ng-template #link2>\n\n                        <span *ngIf='bonus then discover1 else discover2'></span>\n                        <ng-template #discover1>\n                          <p style=\"color:white;margin-top: 8px; \">Video link:\n                          <button value='{{ cur_videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                          <a href='{{ cur_videoLink }}' target='_blank'><button class='discover-button'>discover</button></a></p>\n                        </ng-template>\n                        <ng-template #discover2>\n                        <p style=\"color:white;margin-top: 8px; \">Video link:\n                        <button value='{{ cur_videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                          <button class='discover-button' (click)=\"getSubscriptionPage()\">discover</button></p>\n                        </ng-template>\n                      </ng-template>\n                </div>\n                <div class=\"col-md-2 text-center\" *ngIf=\"cur_useremail != currentUser.msg.email\">\n                    <br>\n                    <button  (click) = 'openTextarea( cur_id, cur_userId, cur_useremail )' class='answer-button'>Answer</button>\n                    <button (click)=\"subscribePost( cur_id, cur_userId, '0', cur_name )\" class='answer-button' style='background-color:#e62c22;margin-top:10px;'>Subscribe to posts</button>\n                    <button class='answer-button' (click) = 'closelookingmore()' style = 'margin-top:10px;background-color:grey;'>Close</button>\n                </div>\n                <div class=\"col-md-2 text-center\" *ngIf=\"cur_useremail == currentUser.msg.email\">\n                    <br><br>\n                    <button class='answer-button' (click) = 'closelookingmore()' style = 'margin-top:10px;background-color:grey;'>Close</button>\n                </div>\n    </div>\n</div>\n<div class=\"content\" #scrollMe [scrollTop]=\"scrollMe.scrollHeight\">\n  <div  [ngSwitch]=\"pageName\">\n    <div *ngSwitchCase=\"'getSub'\" class= 'row'>\n      <div class='col-md-2'></div>\n      <div class='col-md-4'>\n        <div>\n          <br>\n          <p>- Access to the \"responses received\" room.</p>\n          <p>- The possibility of adding a Youtube link to these \"messages and replies\" posts.</p>\n          <p>Take advantage of all of our features for: </p><br>\n          <p> - 30 days: 14.99 &euro;</p>\n          <p> - 15 days: 9.99 &euro;</p><br>\n          <p>Wifball offers you the opportunity to have relevant and informative discussions with whomever you want around world football.</p>\n        </div>\n      </div>\n      <div class='col-md-1'></div>\n      <div class='col-md-3'>\n        <br><br>\n        <h5>Subscription for 30 days: </h5>\n        <a routerLink=\"/subscription30\" ><button class='goto_pay'> 30 days </button></a>\n\n        <br><br>\n        <h5>Subscription for 15 days: </h5>\n        <a routerLink=\"/subscription15\" ><button class='goto_pay'> 15 days </button></a>\n      </div>\n      <div class='col-md-2'></div>\n    </div>\n    <div *ngSwitchCase=\"'response'\">\n      <div *ngFor=\"let item of responseArray\">\n        <div class=\"subpart\" *ngIf = 'item.userdetail[0].email'>\n            <div class=\"row\">\n                <div class=\"col-md-1 text-center\">\n                  <br><br>\n                    <span *ngIf=\"item.userdetail[0].photoUrl==null || item.userdetail[0].img_state==0 then image1 else image2\">\n                      <img src=\"/assets/image/user1.png\" class='sub-photo-img'>\n                    </span>\n                    <ng-template #image1><img src=\"/assets/image/login.jpg\" class='sub-photo-img'></ng-template>\n                    <ng-template #image2><img src=\"http://192.162.69.178:3000/images/{{ item.userdetail[0].photoUrl }}\" class='sub-photo-img'></ng-template>\n                    <p style=\"color:white;margin-top: 8px;\">{{ item.userdetail[0].pseduo }}</p>\n                </div>\n                <div class=\"col-md-9\">\n                    <p style=\"color:white;margin-top: 8px;\">Response to: <span class='span-div'>{{ item.userdetail[0].pseduo }}</span></p>\n                    <div style='width:100%; max-height: 80px; overflow-y: scroll; border-radius:8px;background-color:white;padding:5px;'><pre>{{ item.answer[0].message }}</pre></div>\n                      <span *ngIf='item.answer[0].videoLink==null || item.answer[0].videoLink==\"\" then link1 else link2'>\n                      </span>\n                      <ng-template #link1>\n                        <p style=\"color:white;margin-top: 8px; \">Video link:\n                        <button value='{{ item.answer[0].videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> No Linked </button>\n                        <a href='{{ item.answer[0].videoLink }}' target='_blank'><button class='discover-button'>discover</button></a><button style='background-color: lightgrey;color: red; border-radius: 4px; margin-left: 15px;' (click)='message_block(item.owner)'>Block responses</button></p>\n                      </ng-template>\n                      <ng-template #link2>\n                        <p style=\"color:white;margin-top: 8px; \">Video link:\n                        <button value='{{ item.answer[0].videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                        <a href='{{ item.answer[0].videoLink }}' target='_blank'><button class='discover-button'>discover</button></a><button style='background-color: lightgrey;color: red; border-radius: 4px; margin-left: 15px;' (click)='message_block(item.owner)'>Block responses</button></p>\n                      </ng-template>\n                </div>\n                <div class=\"col-md-2 text-center\" *ngIf=\"item.owner != currentUser.msg._id\">\n                    <br><br>\n                    <button class='answer-button' (click) = 'openTextarea( item.message_id, item.userdetail[0]._id, item.userdetail[0].email )'>Answer</button>\n                    <button (click)=\"subscribePost( item.owner, item.answer[0].message, item.answer[0].videoLink, item.userdetail[0].pseduo )\" class='answer-button' style='background-color:#e62c22;margin-top:10px;'>Subscribe to posts</button>\n                </div>\n            </div>\n        </div>\n      </div>\n    </div>\n    <div *ngSwitchCase=\"'subscriber'\">\n      <div *ngFor=\"let item of postArray\">\n        <div class=\"subpart\" *ngIf = 'item.userdetail[0].email'>\n            <div class=\"row\">\n                <div class=\"col-md-1 text-center\">\n                  <br>\n                    <span *ngIf=\"item.userdetail[0].photoUrl==null || item.userdetail[0].img_state==0 then image1 else image2\">\n                      <img src=\"/assets/image/login.jpg\" class='sub-photo-img'>\n                    </span>\n                    <ng-template #image1><img src=\"/assets/image/login.jpg\" class='sub-photo-img'></ng-template>\n                    <ng-template #image2><img src=\"http://192.162.69.178:3000/images/{{ item.userdetail[0].photoUrl }}\" class='sub-photo-img'></ng-template>\n                    <p style=\"color:white;\">{{ item.userdetail[0].pseduo }}</p>\n                </div>\n                <div class=\"col-md-9\">\n                    <br>\n                    <div style='width:100%; max-height: 80px; overflow-y: scroll; border-radius:8px;background-color:white;padding:5px;'><pre>{{ item.message }}</pre></div>\n                    <span *ngIf='item.videoLink==null || item.videoLink==\"\" then link1 else link2'>\n                    </span>\n                      <ng-template #link1>\n                         <p style=\"color:white;margin-top: 8px;\">Video link:\n                        <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> No link </button>\n                        <button class='discover-button'>discover</button></p>\n                      </ng-template>\n                      <ng-template #link2>\n                        <span *ngIf='bonus then discover1 else discover2'></span>\n                        <ng-template #discover1>\n                          <p style=\"color:white;margin-top: 8px;\">Video link:\n                          <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                          <a href='{{ item.videoLink }}' target='_blank'><button class='discover-button'>discover</button></a></p>\n                        </ng-template>\n                        <ng-template #discover2>\n                        <p style=\"color:white;margin-top: 8px;\">Video link:\n                        <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                          <button class='discover-button' (click)=\"getSubscriptionPage()\">discover</button></p>\n                        </ng-template>\n                      </ng-template>\n                </div>\n                <div class=\"col-md-2 text-center\" *ngIf=\"item.useremail != currentUser.msg.email\">\n                    <br><br>\n                    <button class='answer-button' (click) = 'openTextarea( item._id, item.userId, item.useremail )'>Answer</button>\n                    <button (click)=\"unsubscribePost( item._id, item.userId, item.userdetail[0].pseduo )\" class='answer-button' style='background-color:#e62c22;margin-top:10px;'>unsubscribe to posts</button>\n                </div>\n            </div>\n        </div>\n      </div>\n    </div>\n    <div *ngSwitchDefault>\n      <div *ngFor=\"let item of messageArray\">\n        <div class=\"subpart\" *ngIf = 'item.userdetail[0].email'>\n            <div class=\"row\" >\n                <div class=\"col-md-1 text-center\">\n                  <br>\n                    <span *ngIf=\"item.userdetail[0].photoUrl==null || item.userdetail[0].img_state==0 then image1 else image2\">\n                      <img src=\"/assets/image/login.jpg\" class='sub-photo-img'>\n                    </span>\n                    <ng-template #image1><img src=\"/assets/image/login.jpg\" class='sub-photo-img'></ng-template>\n                    <ng-template #image2><img src=\"http://192.162.69.178:3000/images/{{ item.userdetail[0].photoUrl }}\" class='sub-photo-img'></ng-template>\n                    <p style=\"color:white;\">{{ item.userdetail[0].pseduo }}</p>\n                </div>\n                <div class=\"col-md-9\">\n                    <br>\n                    <div style='width:100%; max-height: 80px; overflow-y: scroll; border-radius:8px;background-color:white;padding:5px;' (click)='lookingmore(item.userdetail[0].photoUrl, item.userdetail[0].pseduo, item.message, item.videoLink, item.useremail, item._id, item.userIdm, item.userdetail[0].img_state)'><pre>{{ item.message }}</pre></div>\n                    <span *ngIf='item.videoLink==null || item.videoLink==\"\" then link1 else link2'>\n                    </span>\n                      <ng-template #link1>\n                         <p style=\"color:white;margin-top: 8px;\">Video link:\n                          <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> No link </button>\n                          <button class='discover-button'>discover</button>\n                          <span *ngIf = 'blockusers != null && blockusers.blockId.length != 0'>\n                              <span *ngFor = \"let block of blockusers.blockId\">\n                                <button *ngIf = 'block==item.userId' style='background-color: lightgrey;color: green; border-radius: 4px; margin-left: 15px;' (click)='message_unblock(item.userId)'>Unblock responses</button>\n                              </span>\n                            </span>\n\n                        </p>\n                      </ng-template>\n                      <ng-template #link2>\n                        <span *ngIf='bonus then discover1 else discover2'></span>\n                        <ng-template #discover1>\n                          <p style=\"color:white;margin-top: 8px;\">Video link:\n                            <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                            <a href='{{ item.videoLink }}' target='_blank'>\n                              <button class='discover-button'>discover</button>\n                            </a>\n                            <span *ngIf = 'blockusers != null && blockusers.blockId.length != 0'>\n                              <span *ngFor = \"let block of blockusers.blockId\">\n                                <button *ngIf = 'block==item.userId' style='background-color: lightgrey;color: green; border-radius: 4px; margin-left: 15px;' (click)='message_unblock(item.userId)'>Unblock responses</button>\n                              </span>\n                            </span>\n                          </p>\n                        </ng-template>\n                        <ng-template #discover2>\n                        <p style=\"color:white;margin-top: 8px;\">Video link:\n                        <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button>\n                        <!-- <button value='{{ item.videoLink }}' style='width:70%; border-radius:8px; margin-left:10px;background-color:white;'> Linked </button> -->\n                          <button class='discover-button' (click)=\"getSubscriptionPage()\">discover</button></p>\n                        </ng-template>\n                      </ng-template>\n                </div>\n                <div class=\"col-md-2 text-center\" *ngIf=\"item.useremail != currentUser.msg.email\">\n                    <br><br>\n                    <button  (click) = 'openTextarea( item._id, item.userId, item.useremail )' class='answer-button'>Answer</button>\n                    <button (click)=\"subscribePost( item._id, item.userId, '0', item.userdetail[0].pseduo )\" class='answer-button' style='background-color:#e62c22;margin-top:10px;'>Subscribe to posts</button>\n                </div>\n            </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n<footer class='footer_div'>\n    <div class=\"message\"  *ngIf=\"pageName =='main' || pageName =='getSub'\">\n      <div *ngIf= '!answer_value'>\n        <div class='row'>\n          <div class='col-md-11'>\n            <textarea [(ngModel)]=\"message\" style='width:98%;height:80px; border-radius: 8px; border:2px solid black;'></textarea>\n          </div>\n          <div class='col-md-1'>\n            <button id=\"send\" (click)=\"MessageSend()\" class='send-button'>SEND</button>\n          </div>\n        </div>\n        <div class='row'  style='margin-top:6px;' >\n          <div class='col-md-8'>\n            <p style='color:white;'>Add youtube link: <input [(ngModel)]=\"videoLink\" type='text' style='border-radius:6px; width:60%; margin-left:10px;' (click)='checklink()'></p>\n          </div>\n          <div class='col-md-4'>\n\n          </div>\n        </div>\n        <div class='text-center' style='position:relative;'>\n            <p style='color:yellow; margin-bottom: 0; padding-bottom: 1rem;'>SITE UNDER SURVEILLANCE. BE CAREFUL. DISCUSS AS A TEAM.<br><span style='color:red;'> - Account blocking in the event of non-compliance - </span><br><span style='color:white;'>WIFBALL</span></p>\n            <div style='background-color:#414141; position: absolute; right:15px; top:10px; color:white; border-radius: 8px;height:40px;padding-left:20px; padding-top:7px;width:250px;'>\n              <i style='padding-left: 16px; padding-top: 14px;'>Refresh room</i>\n              <button (click) = \"refreshMessage()\" style='background-color:#A3DC1F;border-radius:8px;border:none; float:right;margin-top:-7px;'><i class=\"fa fa-refresh\" style=\"font-size:35px;color:white;background-color:#A3DC1F;\"></i></button>\n            </div>\n        </div>\n      </div>\n      <div *ngIf = 'answer_value' >\n          <div class='row'>\n            <div class='col-md-11'>\n              <textarea [(ngModel)]=\"message\" style='width:98%;height:80px; border-radius: 8px; border:2px solid black;'></textarea>\n            </div>\n            <div class='col-md-1'>\n              <button id=\"send\" (click)=\"MessageSend()\" class='send-button'>Answer</button>\n            </div>\n          </div>\n          <div class='row' style='margin-top:6px;' >\n            <div class='col-md-10'>\n              <p style='color:white;'>Add youtube link: <input [(ngModel)]=\"videoLink\" type='text' style='border-radius:6px; width:60%;margin-left:10px;'></p>\n            </div>\n            <div class='col-md-2'>\n              <button id=\"cancel\" (click)=\"answerCancel()\" class='cancel_button'>Cancel</button>\n            </div>\n          </div>\n          <div class='text-center' style='position:relative;'>\n            <p style='color:yellow; margin-bottom: 0; padding-bottom: 1rem;'>SITE UNDER SURVEILLANCE. BE CAREFUL. DISCUSS AS A TEAM.<br><span style='color:red;'> - Account blocking in the event of non-compliance - </span><br><span style='color:white;'>WIFBALL</span></p>\n            <div style='background-color:#414141; position: absolute; right:15px; top:10px; color:white; border-radius: 8px;height:40px;padding-left:20px; padding-top:7px;width:250px;'>\n              <i style='padding-left: 16px; padding-top: 14px;'>Refresh room</i>\n              <button (click) = \"refreshMessage()\" style='background-color:#A3DC1F;border-radius:8px;border:none; float:right;margin-top:-7px;'><i class=\"fa fa-refresh\" style=\"font-size:35px;color:white;background-color:#A3DC1F;\"></i></button>\n            </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"message\"  *ngIf=\"pageName =='response' || pageName =='subscriber'\">\n      <div class='row'>\n          <div class='col-md-11'>\n            <textarea [(ngModel)]=\"message\" style='width:98%;height:80px; border-radius: 8px; border:2px solid black;'></textarea>\n          </div>\n          <div class='col-md-1'>\n            <button id=\"send\" (click)=\"MessageSend()\" class='send-button'>Answer</button>\n          </div>\n        </div>\n        <div class='row'  style='margin-top:6px;' >\n          <div class='col-md-8'>\n            <p style='color:white;'>Add youtube link: <input [(ngModel)]=\"videoLink\" type='text' style='border-radius:6px; width:60%;margin-left:10px;' (click)='checklink()'></p>\n          </div>\n          <div class='col-md-4'>\n            <!-- <div class='back-green-div' style='background-color:#414141;'>\n              <i style='padding-left: 16px; padding-top: 14px;'>Refresh room</i>\n              <button (click) = \"refreshMessage()\" style='background-color:#A3DC1F;border-radius:8px;border:none; float:right;margin-top:-7px;'><i class=\"fa fa-refresh\" style=\"font-size:35px;color:white;background-color:#A3DC1F;\"></i></button>\n            </div> -->\n          </div>\n        </div>\n        <div class='text-center' style='position:relative;'>\n            <p style='color:yellow; margin-bottom: 0; padding-bottom: 1rem;'>SITE UNDER SURVEILLANCE. BE CAREFUL. DISCUSS AS A TEAM.<br><span style='color:red;'> - Account blocking in the event of non-compliance - </span><br><span style='color:white;'>WIFBALL</span></p>\n            <div style='background-color:#414141; position: absolute; right:15px; top:10px; color:white; border-radius: 8px;height:40px;padding-left:20px; padding-top:7px;width:250px;'>\n              <i style='padding-left: 16px; padding-top: 14px;'>Refresh room</i>\n              <button (click) = \"refreshMessage()\" style='background-color:#A3DC1F;border-radius:8px;border:none; float:right;margin-top:-7px;'><i class=\"fa fa-refresh\" style=\"font-size:35px;color:white;background-color:#A3DC1F;\"></i></button>\n            </div>\n        </div>\n    </div>\n</footer>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/privacy/privacy.component.html":
  /*!**************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/privacy/privacy.component.html ***!
    \**************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPrivacyPrivacyComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class='container'><br><br>\n<h1>Privacy and Confidentiality Policy</h1>\n<p>Wifball (reig guy-charles) (the \"Company\", \"us\" or \"us\") care about your privacy.\nThis Privacy Policy (\"Privacy Policy\") explains the Company's policies and procedures\nregarding the collection, use and disclosure of information and personal data that we receive from users\nof the website that we own and operate, namely http://ingloball.com / (the site \"). This privacy policy applies\nonly to information collected through the site.\nThis privacy policy is part of and is integrated into our general conditions of sale and use.\nBy visiting this site, you accept the policies and practices described in this privacy policy,\nas this privacy policy may be changed from time to time. Each time you visit the site, you expressly\naccept and consent to our collection, use and disclosure of the information you provide, as described in this privacy policy.\n</p><br><br>\n<h2>Collection of your personal information</h2>\n<p>The information we collect from you helps us personalize and improve the experience of users of our website. This information includes:<br>\n- Last name First Name;<br>\n- E-mail adress;<br>\nInformation about your use of our website may also be obtained through the use of \"cookies\".<br>\nWe will not collect sensitive information without your consent and will not collect any of this information secretly or dishonestly.\n</p><br>\n\n<h2>Use of your personal information</h2>\n<p>The primary use of your personal information is for the purposes listed above under the heading\nCollection of your personal information. However, we will use and disclose your personal information\nfor approved purposes and in various ways associated with approved purposes, including:<br><br>\nCommunicate with you;<br>\nAssist in the development of information technology, maintenance and development of systems;<br>\nAnalyze information for product development, marketing and research purposes and to improve and expand our range of products and services;<br>\nTo investigate and resolve complaints regarding the provision of services by us or by others associated with us;<br>\nMarketing directly to you;<br>\nDisclosure of your personal information to any other organization or person involved in the performance of any\nnecessary function or activity on our behalf, including handling complaints and preventing fraud;<br>\nDisclosure of your personal information in a manner authorized or required by law;<br>\nFor compliance with laws and regulations.\n</p><br>\n\n<h2>Disclosure of your personal information</h2>\n<p>\nWe may use and disclose your personal information for approved purposes and\nin various ways associated with approved purposes. This includes the following:\nWe may disclose personal information to third parties to allow outsourcing of\nfunctions. This will be done when this disclosure meets your reasonable expectations.\nWe will take reasonable steps to ensure that our contracts with third parties include\nrequirements that require third parties to comply with the usage and disclosure requirements in accordance with our privacy policy.\nWe may disclose personal information to law enforcement, government agencies, the courts\n or outside counsel when the law allows or requires it.\nWe may disclose personal information to avoid an imminent threat to the life of an individual or to public safety.\nWe do not sell or share the lists of users of our website on a commercial basis with third parties.</p><br>\n\n<h2>Information security</h2>\n<p>We will take reasonable steps to ensure the security of your personal information against risks such as loss or\nunauthorized access, destruction, use, modification or disclosure of data. We only allow access to your contact details\nto authorized personnel.</p><br>\n\n<h3>Secure transmission of your personal account details</h3>\n<p>We strive to protect your personal information during transmission. User account information provided through this site is\nkept in a secure server environment behind the Company's firewalls.\nAll personal information is transmitted using 128-bit secure server software (SSL), the latest industry standard encryption,\nto protect the loss, misuse or modification of your personal information under our control.</p><br>\n\n<h3>Cookies and other technologies</h3>\n<p>We use cookies and other technologies to help us determine which components of our website are most popular.\nCookies can also be used to study traffic patterns and, most importantly, to make sure that your experience of\ninteracting with us is practical.\nWe generally do not use this information collected for purposes beyond the scope of this privacy policy.\n</p><br>\n\n\n\n<h3>Unsubscribe from marketing communications</h3>\n<p>When you provide us with personal information from time to time, you may be asked to indicate\nif you would like to receive information from us about special offers related to the site and services.\nUnless you opt out of receiving such communications, we may from time to time send you marketing communications.\nAt any time, you can choose to stop receiving commercial or promotional emails from us by sending us an email.\nIn addition, in any promotional email we send, you will have the option to opt out of receiving such messages\nin the future by clicking on the link at the bottom of the email that says \"unsubscribe\".\n</p><br>\n\n<h3>Information for children</h3>\n<p>The Site is not intended or intended for children under the age of 18. We do not knowingly collect or solicit\npersonal information from anyone under the age of 18. If we obtain actual knowledge that a user is under the age\nof 18, we will take steps to delete that user's personal information from our systems.\n</p><br>\n\n<h3>Changes to this privacy policy</h3>\n<p>This privacy policy may change from time to time. These changes will be highlighted in this area at the time of the change.</p><br>\n\n<h2>Contact Us</h2>\n<p>If you have any questions or suggestions regarding the privacy or security of our site, please contact us by email.</p><br>\n\n<div class='text-center'><a routerLink=\"/login\">Back</a></div><br><br>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterRegisterComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div *ngIf='warning' class='warning-div'>{{ warning_message }}<button (click)='closeWarningbutton()' class='warning-button'><i class=\"fa fa-close\" style=\"font-size:17px;color:lightgreen\"></i></button></div>\n<header>\n    <img src=\"../../assets/Wifball logo.png\" alt=\"\">\n    <h1>discuss football and make the best decisions for your online betting</h1>\n</header>\n<div class=\"row back_3\">\n  <div class=\"col-md-6\" style=\"margin-left: auto;margin-right:auto;\">\n  <div class=\"container\" style=\"width:80%\">\n    <div class=\"form-wrap\"style=\"padding-top:8%\">\n        <form [formGroup]=\"registerForm\" (ngSubmit)=\"register()\">\n            <h1 >Sign up</h1>\n          <div class=\"input-wrap\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Name</mat-label>\n              <input matInput type=\"text\" name=\"name\" [formControl]=\"name\" placeholder=\"Name\">\n            </mat-form-field>\n          </div>\n          <div class=\"input-wrap\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Email</mat-label>\n              <input matInput type=\"email\" name=\"email\" [formControl]=\"email\" placeholder=\"Email\">\n              <mat-error *ngIf=\"email.hasError('pattern')\">\n                Please enter a valid email address\n              </mat-error>\n              <mat-error *ngIf=\"email.hasError('required')\">\n                Email is\n                <strong>required</strong>\n              </mat-error>\n            </mat-form-field>\n          </div>\n          <div class=\"input-wrap\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Nickname</mat-label>\n              <input matInput type=\"text\" name=\"pseduo\" [formControl]=\"pseduo\" placeholder=\"Nickname\">\n              <!-- <mat-error *ngIf=\"email.hasError('pattern')\">\n                Please enter a valid email address\n              </mat-error>\n              <mat-error *ngIf=\"email.hasError('required')\">\n                Email is\n                <strong>required</strong>\n              </mat-error> -->\n            </mat-form-field>\n          </div>\n          <div class=\"input-wrap\">\n            <mat-form-field appearance=\"outline\">\n                <mat-label>Password</mat-label>\n              <input matInput type=\"password\" name=\"password\" [formControl]=\"password\" placeholder=\"Password\" >\n              <mat-error *ngIf=\"password.hasError('minlength')\">\n                Password must be at least 6 characters long\n              </mat-error>\n              <mat-error *ngIf=\"password.hasError('required')\">\n                Password is\n                <strong>required</strong>\n              </mat-error>\n            </mat-form-field>\n          </div>\n          <div class=\"recaptcha\" style=\"margin:auto;text-align: center;padding-top:30px\">\n            <re-captcha (resolved)=\"resolved($event)\" siteKey=\"6LdCXPQUAAAAAC8lgskB60g_DDesYpOdO1IDUZhM\"></re-captcha>\n        </div>\n            <!-- <button mat-raised-button type=\"submit\" [disabled]=\"!loginForm.valid\" color=\"primary\" style=\"width: 70%;\"> -->\n          <!-- <div style=\"margin:auto;text-align: center;\">\n            <div #recaptcha ></div>\n          </div> -->\n            <button mat-raised-button type=\"submit\" color=\"primary\" style=\"width: 70%;height:auto;margin-top:30px;padding:10px 10px\">\n            <i class=\"fa fa-paper-plane\"></i> Continue\n          </button><br><br><a routerLink=\"/login\" style=\"text-align: left!important;\">Back</a><br>\n          <div class='row' style = 'color: green;font-weight:bold;'>\n            <div class='col-md-4'><a  routerLink=\"/condition\" style = 'color: green;font-weight:bold;' >CGU/CGV</a></div>\n              <div class='col-md-4 text-center'><a routerLink=\"/privacy\" style = 'color: green;font-weight:bold;' >privacy policy</a></div>\n              <div class='col-md-4'><a  routerLink=\"/legal\" style = 'color: green;font-weight:bold;' >Legal Notice</a></div>\n         </div>\n        </form>\n      </div>\n</div>\n</div>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/subscription/subscription.component.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subscription/subscription.component.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSubscriptionSubscriptionComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<p>subscription works!</p>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/update/update.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/update/update.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUpdateUpdateComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<p>update works!</p>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/user-authentication/user-authentication.component.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-authentication/user-authentication.component.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUserAuthenticationUserAuthenticationComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/wifpaypal/wifpaypal.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/wifpaypal/wifpaypal.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppWifpaypalWifpaypalComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n<div class='row back_franceimage' style = 'padding-top:70px;'>\n  <div class='col-md-4'></div>\n  <div class='col-md-4'>\n  <div style='border-radius:8px; padding: 25px;background-color: lightblue' *ngIf = 'warning'>\n    <p>{{ warning_message }}</p>\n  </div><br>\n  <div style='border-radius:8px; padding: 25px;background-color: lightblue'>\n    <br>\n    <h5>For the 15 days pay</h5>\n    <br>\n    <p>15 days of benefits:</p><br>\n    <p>- Access to the \"responses received\" room.</p>\n    <p>- The possibility of adding a Youtube link to these \"messages and replies\" posts.</p>\n    <br>\n    <ngx-paypal [config]=\"payPalConfig\"></ngx-paypal>\n    <br>\n    <div class='text-center' *ngIf = '!warning'><button class = 'cancel_button' (click) = 'cancel()' style='background-color:grey;'>Back</button><button class = 'cancel_button' (click) = 'confirm()' style='margin-left: 20px;'>Confirm</button></div>\n    <div class='text-center' *ngIf = 'warning'><button class = 'cancel_button' >Please wait...</button></div>\n    <br><p>Note: You need to wait for a while to confirm the subscripton after payment.</p>\n    </div>\n  </div>\n  <div class='col-md-4'></div>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/wifpaypal30/wifpaypal30.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/wifpaypal30/wifpaypal30.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppWifpaypal30Wifpaypal30ComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n<div class='row back_franceimage' style = 'padding-top:70px;'>\n  <div class='col-md-4'></div>\n  <div class='col-md-4'>\n  <div style='border-radius:8px; padding: 25px;background-color: lightblue' *ngIf = 'warning'>\n    <p>{{ warning_message }}</p>\n  </div><br>\n  <div style='border-radius:8px; padding: 25px;background-color: lightblue'>\n    <br>\n    <h5>For the 30 days pay</h5>\n    <br>\n    <p>30 days of benefits:</p><br>\n    <p>- Access to the \"responses received\" room.</p>\n    <p>- The possibility of adding a Youtube link to these \"messages and replies\" posts.</p>\n\n    <br>\n    <ngx-paypal [config]=\"payPalConfig\"></ngx-paypal>\n    <br>\n    <div class='text-center' *ngIf = '!warning'><button class = 'cancel_button' (click) = 'cancel()' style='background-color:grey;'>Back</button><button class = 'cancel_button' (click) = 'confirm()' style='margin-left: 20px;'>Confirm</button></div>\n    <div class='text-center' *ngIf = 'warning'><button class = 'cancel_button' >Please wait...</button></div>\n    <br><p>Note: You need to wait for a while to confirm the subscripton after payment.</p>\n\n    </div>\n  </div>\n  <div class='col-md-4'></div>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0
    
    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : new P(function (resolve) {
            resolve(result.value);
          }).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (!exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var m = typeof Symbol === "function" && o[Symbol.iterator],
          i = 0;
      if (m) return m.call(o);
      return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result.default = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        default: mod
      };
    }
    /***/

  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _main_main_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./main/main.component */
    "./src/app/main/main.component.ts");
    /* harmony import */


    var _shared_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./shared/auth.guard */
    "./src/app/shared/auth.guard.ts");
    /* harmony import */


    var _login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./login/login.component */
    "./src/app/login/login.component.ts");
    /* harmony import */


    var _register_register_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./register/register.component */
    "./src/app/register/register.component.ts");
    /* harmony import */


    var _forget_forget_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./forget/forget.component */
    "./src/app/forget/forget.component.ts");
    /* harmony import */


    var _wifpaypal_wifpaypal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./wifpaypal/wifpaypal.component */
    "./src/app/wifpaypal/wifpaypal.component.ts");
    /* harmony import */


    var _wifpaypal30_wifpaypal30_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./wifpaypal30/wifpaypal30.component */
    "./src/app/wifpaypal30/wifpaypal30.component.ts");
    /* harmony import */


    var _subscription_subscription_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./subscription/subscription.component */
    "./src/app/subscription/subscription.component.ts");
    /* harmony import */


    var _conditionuse_conditionuse_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./conditionuse/conditionuse.component */
    "./src/app/conditionuse/conditionuse.component.ts");
    /* harmony import */


    var _legalnotice_legalnotice_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./legalnotice/legalnotice.component */
    "./src/app/legalnotice/legalnotice.component.ts");
    /* harmony import */


    var _privacy_privacy_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./privacy/privacy.component */
    "./src/app/privacy/privacy.component.ts");

    var routes = [{
      path: '',
      redirectTo: '/login',
      pathMatch: 'full'
    }, {
      path: 'login',
      component: _login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"]
    }, {
      path: 'register',
      component: _register_register_component__WEBPACK_IMPORTED_MODULE_6__["RegisterComponent"]
    }, {
      path: 'forget',
      component: _forget_forget_component__WEBPACK_IMPORTED_MODULE_7__["ForgetComponent"]
    }, {
      path: 'main/:id',
      component: _main_main_component__WEBPACK_IMPORTED_MODULE_3__["MainComponent"],
      canActivate: [_shared_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]]
    }, {
      path: 'getsubscription',
      component: _subscription_subscription_component__WEBPACK_IMPORTED_MODULE_10__["SubscriptionComponent"]
    }, {
      path: 'subscription15',
      component: _wifpaypal_wifpaypal_component__WEBPACK_IMPORTED_MODULE_8__["WifpaypalComponent"]
    }, {
      path: 'subscription30',
      component: _wifpaypal30_wifpaypal30_component__WEBPACK_IMPORTED_MODULE_9__["Wifpaypal30Component"]
    }, {
      path: 'condition',
      component: _conditionuse_conditionuse_component__WEBPACK_IMPORTED_MODULE_11__["ConditionuseComponent"]
    }, {
      path: 'privacy',
      component: _privacy_privacy_component__WEBPACK_IMPORTED_MODULE_13__["PrivacyComponent"]
    }, {
      path: 'legal',
      component: _legalnotice_legalnotice_component__WEBPACK_IMPORTED_MODULE_12__["LegalnoticeComponent"]
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AppComponent = function AppComponent() {
      _classCallCheck(this, AppComponent);

      this.title = 'frontend';
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss")).default]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var ng2_file_upload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ng2-file-upload */
    "./node_modules/ng2-file-upload/fesm2015/ng2-file-upload.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/fesm2015/animations.js");
    /* harmony import */


    var _user_authentication_user_authentication_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./user-authentication/user-authentication.component */
    "./src/app/user-authentication/user-authentication.component.ts");
    /* harmony import */


    var _login_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./login/login.component */
    "./src/app/login/login.component.ts");
    /* harmony import */


    var _register_register_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./register/register.component */
    "./src/app/register/register.component.ts");
    /* harmony import */


    var _material_material_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./material/material.module */
    "./src/app/material/material.module.ts");
    /* harmony import */


    var _loading_loading_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./loading/loading.component */
    "./src/app/loading/loading.component.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _main_main_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./main/main.component */
    "./src/app/main/main.component.ts");
    /* harmony import */


    var _wifpaypal_wifpaypal_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./wifpaypal/wifpaypal.component */
    "./src/app/wifpaypal/wifpaypal.component.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _shared_authconfig_interceptor__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./shared/authconfig.interceptor */
    "./src/app/shared/authconfig.interceptor.ts");
    /* harmony import */


    var _forget_forget_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./forget/forget.component */
    "./src/app/forget/forget.component.ts");
    /* harmony import */


    var _update_update_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./update/update.component */
    "./src/app/update/update.component.ts");
    /* harmony import */


    var ng_recaptcha__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ng-recaptcha */
    "./node_modules/ng-recaptcha/fesm2015/ng-recaptcha.js");
    /* harmony import */


    var ngx_timer__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! ngx-timer */
    "./node_modules/ngx-timer/fesm2015/ngx-timer.js");
    /* harmony import */


    var ngx_paypal__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! ngx-paypal */
    "./node_modules/ngx-paypal/fesm2015/ngx-paypal.js");
    /* harmony import */


    var _subscription_subscription_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! ./subscription/subscription.component */
    "./src/app/subscription/subscription.component.ts");
    /* harmony import */


    var _wifpaypal30_wifpaypal30_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! ./wifpaypal30/wifpaypal30.component */
    "./src/app/wifpaypal30/wifpaypal30.component.ts");
    /* harmony import */


    var _conditionuse_conditionuse_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! ./conditionuse/conditionuse.component */
    "./src/app/conditionuse/conditionuse.component.ts");
    /* harmony import */


    var _privacy_privacy_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! ./privacy/privacy.component */
    "./src/app/privacy/privacy.component.ts");
    /* harmony import */


    var _legalnotice_legalnotice_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
    /*! ./legalnotice/legalnotice.component */
    "./src/app/legalnotice/legalnotice.component.ts"); // by ftf


    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"], _user_authentication_user_authentication_component__WEBPACK_IMPORTED_MODULE_7__["UserAuthenticationComponent"], _login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"], _register_register_component__WEBPACK_IMPORTED_MODULE_9__["RegisterComponent"], _loading_loading_component__WEBPACK_IMPORTED_MODULE_11__["LoadingComponent"], _main_main_component__WEBPACK_IMPORTED_MODULE_13__["MainComponent"], _forget_forget_component__WEBPACK_IMPORTED_MODULE_17__["ForgetComponent"], _update_update_component__WEBPACK_IMPORTED_MODULE_18__["UpdateComponent"], _wifpaypal_wifpaypal_component__WEBPACK_IMPORTED_MODULE_14__["WifpaypalComponent"], _subscription_subscription_component__WEBPACK_IMPORTED_MODULE_22__["SubscriptionComponent"], _wifpaypal30_wifpaypal30_component__WEBPACK_IMPORTED_MODULE_23__["Wifpaypal30Component"], _conditionuse_conditionuse_component__WEBPACK_IMPORTED_MODULE_24__["ConditionuseComponent"], _privacy_privacy_component__WEBPACK_IMPORTED_MODULE_25__["PrivacyComponent"], _legalnotice_legalnotice_component__WEBPACK_IMPORTED_MODULE_26__["LegalnoticeComponent"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"], _material_material_module__WEBPACK_IMPORTED_MODULE_10__["MaterialModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ReactiveFormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientModule"], ng_recaptcha__WEBPACK_IMPORTED_MODULE_19__["RecaptchaModule"], ngx_timer__WEBPACK_IMPORTED_MODULE_20__["NgxTimerModule"], ngx_paypal__WEBPACK_IMPORTED_MODULE_21__["NgxPayPalModule"], ng2_file_upload__WEBPACK_IMPORTED_MODULE_3__["FileUploadModule"]],
      providers: [{
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HTTP_INTERCEPTORS"],
        useClass: _shared_authconfig_interceptor__WEBPACK_IMPORTED_MODULE_16__["AuthInterceptor"],
        multi: true
      }],
      schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["CUSTOM_ELEMENTS_SCHEMA"]],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/conditionuse/conditionuse.component.scss":
  /*!**********************************************************!*\
    !*** ./src/app/conditionuse/conditionuse.component.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppConditionuseConditionuseComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbmRpdGlvbnVzZS9jb25kaXRpb251c2UuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/conditionuse/conditionuse.component.ts":
  /*!********************************************************!*\
    !*** ./src/app/conditionuse/conditionuse.component.ts ***!
    \********************************************************/

  /*! exports provided: ConditionuseComponent */

  /***/
  function srcAppConditionuseConditionuseComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConditionuseComponent", function () {
      return ConditionuseComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var ConditionuseComponent =
    /*#__PURE__*/
    function () {
      function ConditionuseComponent() {
        _classCallCheck(this, ConditionuseComponent);
      }

      _createClass(ConditionuseComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return ConditionuseComponent;
    }();

    ConditionuseComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-conditionuse',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./conditionuse.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/conditionuse/conditionuse.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./conditionuse.component.scss */
      "./src/app/conditionuse/conditionuse.component.scss")).default]
    })], ConditionuseComponent);
    /***/
  },

  /***/
  "./src/app/forget/forget.component.scss":
  /*!**********************************************!*\
    !*** ./src/app/forget/forget.component.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppForgetForgetComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "header {\n  position: relative;\n  background-color: #04af74 !important;\n  height: 100px;\n}\n\nimg {\n  height: 100%;\n  padding: 0;\n  margin: 0;\n}\n\nheader h1 {\n  position: absolute;\n  color: white;\n  font-size: 25px;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.row {\n  height: calc(100% - 100px);\n  width: 100%;\n  background-image: url('back_3.jpg');\n  background-repeat: no-repeat;\n  background-size: cover;\n  margin: 0px;\n}\n\n.form-wrap {\n  text-align: center;\n  background: url('login_.png'), rgba(255, 255, 255, 0.8);\n  background-blend-mode: color-dodge;\n  background-size: cover;\n  border-radius: 10%;\n  width: 60%;\n  height: 80%;\n  margin-top: 10px;\n  padding: 5% 5%;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.form-wrap .input-wrap {\n  margin: 5px 0;\n}\n\n.form-wrap .mat-form-field {\n  width: 100%;\n}\n\nh1 {\n  color: #3867d5;\n  font-size: 46px;\n}\n\np > span {\n  color: #3867d5;\n  font-size: 18px;\n}\n\nh4 {\n  margin-top: 20px;\n}\n\np {\n  text-align: left !important;\n  margin-bottom: 5px;\n}\n\n.mat-form-field-wrapper::after {\n  padding-bottom: 0px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9yZ2V0L0U6XFxwcm9qZWN0c1xcTm9kZStBbmd1bGFyXFxmb290YmFsbCBiZXR0aW5nIHNpdGVcXGZyb250IGVuZCBvZmZpIHdpZmJhbGwgMlxcZnJvbnQgZW5kL3NyY1xcYXBwXFxmb3JnZXRcXGZvcmdldC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvZm9yZ2V0L2ZvcmdldC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0Esb0NBQUE7RUFDQSxhQUFBO0FDQ0o7O0FEQ0E7RUFDSSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QUNFSjs7QURBQTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLHdDQUFBO1VBQUEsZ0NBQUE7QUNHSjs7QUREQTtFQUNJLDBCQUFBO0VBQ0EsV0FBQTtFQUNBLG1DQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7QUNJSjs7QUREQTtFQUNJLGtCQUFBO0VBUUEsdURBQUE7RUFDQSxrQ0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFFQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx3Q0FBQTtVQUFBLGdDQUFBO0FDSko7O0FEZkk7RUFDSSxhQUFBO0FDaUJSOztBRGZJO0VBQ0ksV0FBQTtBQ2lCUjs7QURBQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FDR0o7O0FEREE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQ0lKOztBREZBO0VBQ0ksZ0JBQUE7QUNLSjs7QURIQTtFQUNJLDJCQUFBO0VBQ0Esa0JBQUE7QUNNSjs7QURKQTtFQUNLLDhCQUFBO0FDT0wiLCJmaWxlIjoic3JjL2FwcC9mb3JnZXQvZm9yZ2V0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaGVhZGVye1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDQsIDE3NSwgMTE2KSFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6MTAwcHg7XHJcbn1cclxuaW1ne1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5oZWFkZXIgaDF7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG59XHJcbi5yb3d7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDEwMHB4KTsgXHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvYmFja18zLmpwZycpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICBtYXJnaW46MHB4O1xyXG59XHJcblxyXG4uZm9ybS13cmFwIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIC5pbnB1dC13cmFwIHtcclxuICAgICAgICBtYXJnaW46IDVweCAwO1xyXG4gICAgfVxyXG4gICAgLm1hdC1mb3JtLWZpZWxkIHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIC8vIHBhZGRpbmc6IDIwJTtcclxuICAgIGJhY2tncm91bmQ6dXJsKCcuLi8uLi9hc3NldHMvbG9naW5fLnBuZycpLHJnYigyNTUsMjU1LDI1NSwwLjgpO1xyXG4gICAgYmFja2dyb3VuZC1ibGVuZC1tb2RlOiBjb2xvci1kb2RnZTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMCU7XHJcbiAgICAvLyBvcGFjaXR5OiAwLjc7XHJcbiAgICB3aWR0aDo2MCU7XHJcbiAgICBoZWlnaHQ6ODAlO1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIHBhZGRpbmc6NSUgNSU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG59XHJcbmgxe1xyXG4gICAgY29sb3I6IHJnYig1NiwxMDMsMjEzKTtcclxuICAgIGZvbnQtc2l6ZTogNDZweDtcclxufVxyXG5wPnNwYW57XHJcbiAgICBjb2xvcjogcmdiKDU2LDEwMywyMTMpO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcbmg0e1xyXG4gICAgbWFyZ2luLXRvcDoyMHB4O1xyXG59XHJcbnB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0IWltcG9ydGFudDtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG4ubWF0LWZvcm0tZmllbGQtd3JhcHBlcjo6YWZ0ZXJ7XHJcbiAgICAgcGFkZGluZy1ib3R0b206IDBweCFpbXBvcnRhbnQ7IFxyXG59IiwiaGVhZGVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDRhZjc0ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMTAwcHg7XG59XG5cbmltZyB7XG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luOiAwO1xufVxuXG5oZWFkZXIgaDEge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAyNXB4O1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn1cblxuLnJvdyB7XG4gIGhlaWdodDogY2FsYygxMDAlIC0gMTAwcHgpO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2JhY2tfMy5qcGdcIik7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIG1hcmdpbjogMHB4O1xufVxuXG4uZm9ybS13cmFwIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvbG9naW5fLnBuZ1wiKSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpO1xuICBiYWNrZ3JvdW5kLWJsZW5kLW1vZGU6IGNvbG9yLWRvZGdlO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBib3JkZXItcmFkaXVzOiAxMCU7XG4gIHdpZHRoOiA2MCU7XG4gIGhlaWdodDogODAlO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBwYWRkaW5nOiA1JSA1JTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn1cbi5mb3JtLXdyYXAgLmlucHV0LXdyYXAge1xuICBtYXJnaW46IDVweCAwO1xufVxuLmZvcm0td3JhcCAubWF0LWZvcm0tZmllbGQge1xuICB3aWR0aDogMTAwJTtcbn1cblxuaDEge1xuICBjb2xvcjogIzM4NjdkNTtcbiAgZm9udC1zaXplOiA0NnB4O1xufVxuXG5wID4gc3BhbiB7XG4gIGNvbG9yOiAjMzg2N2Q1O1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbmg0IHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cblxucCB7XG4gIHRleHQtYWxpZ246IGxlZnQgIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuXG4ubWF0LWZvcm0tZmllbGQtd3JhcHBlcjo6YWZ0ZXIge1xuICBwYWRkaW5nLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/forget/forget.component.ts":
  /*!********************************************!*\
    !*** ./src/app/forget/forget.component.ts ***!
    \********************************************/

  /*! exports provided: ForgetComponent */

  /***/
  function srcAppForgetForgetComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ForgetComponent", function () {
      return ForgetComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _shared_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../shared/auth.service */
    "./src/app/shared/auth.service.ts");

    var ForgetComponent =
    /*#__PURE__*/
    function () {
      function ForgetComponent(auth, formBuilder, router) {
        _classCallCheck(this, ForgetComponent);

        this.auth = auth;
        this.formBuilder = formBuilder;
        this.router = router;
        this.isLoading = false;
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('');
        this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''); // verify:string;

        this.flag = 0;
        this.isLoading = true;
      }

      _createClass(ForgetComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.loginForm = this.formBuilder.group({
            email: this.email
          });
          this.updateForm = this.formBuilder.group({
            password: this.password
          });
        }
      }, {
        key: "login",
        value: function login() {
          this.flag = 1;
          this.auth.forget(this.loginForm.value);
        }
      }, {
        key: "verifyFunc",
        value: function verifyFunc(val) {
          console.log(val);
          console.log('1');

          if (val === 'ntd2gabsqa5lo691knen') {
            this.flag = 2;
          }
        }
      }, {
        key: "resolved",
        value: function resolved(captchaResponse) {
          this.recaptcha = captchaResponse;
          console.log(this.recaptcha);
        }
      }, {
        key: "updateFunc",
        value: function updateFunc() {
          if (!this.recaptcha) {
            alert('You have to check robot verifycation');
          } else {
            this.cVal = {
              "email": this.auth.currentUser.msg.email,
              "password": this.updateForm.value.password,
              "_id": this.auth.currentUser.msg._id,
              "name": this.auth.currentUser.msg.name,
              "pseduo": this.auth.currentUser.msg.pseduo
            };
            this.auth.update(this.cVal);
          }
        }
      }]);

      return ForgetComponent;
    }();

    ForgetComponent.ctorParameters = function () {
      return [{
        type: _shared_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }];
    };

    ForgetComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-forget',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./forget.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/forget/forget.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./forget.component.scss */
      "./src/app/forget/forget.component.scss")).default]
    })], ForgetComponent);
    /***/
  },

  /***/
  "./src/app/legalnotice/legalnotice.component.scss":
  /*!********************************************************!*\
    !*** ./src/app/legalnotice/legalnotice.component.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppLegalnoticeLegalnoticeComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xlZ2Fsbm90aWNlL2xlZ2Fsbm90aWNlLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/legalnotice/legalnotice.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/legalnotice/legalnotice.component.ts ***!
    \******************************************************/

  /*! exports provided: LegalnoticeComponent */

  /***/
  function srcAppLegalnoticeLegalnoticeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LegalnoticeComponent", function () {
      return LegalnoticeComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var LegalnoticeComponent =
    /*#__PURE__*/
    function () {
      function LegalnoticeComponent() {
        _classCallCheck(this, LegalnoticeComponent);
      }

      _createClass(LegalnoticeComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return LegalnoticeComponent;
    }();

    LegalnoticeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-legalnotice',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./legalnotice.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/legalnotice/legalnotice.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./legalnotice.component.scss */
      "./src/app/legalnotice/legalnotice.component.scss")).default]
    })], LegalnoticeComponent);
    /***/
  },

  /***/
  "./src/app/loading/loading.component.scss":
  /*!************************************************!*\
    !*** ./src/app/loading/loading.component.scss ***!
    \************************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoadingLoadingComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".abs-center {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9hZGluZy9FOlxccHJvamVjdHNcXE5vZGUrQW5ndWxhclxcZm9vdGJhbGwgYmV0dGluZyBzaXRlXFxmcm9udCBlbmQgb2ZmaSB3aWZiYWxsIDJcXGZyb250IGVuZC9zcmNcXGFwcFxcbG9hZGluZ1xcbG9hZGluZy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvbG9hZGluZy9sb2FkaW5nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLHdDQUFBO1VBQUEsZ0NBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2xvYWRpbmcvbG9hZGluZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hYnMtY2VudGVyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbn0iLCIuYWJzLWNlbnRlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/loading/loading.component.ts":
  /*!**********************************************!*\
    !*** ./src/app/loading/loading.component.ts ***!
    \**********************************************/

  /*! exports provided: LoadingComponent */

  /***/
  function srcAppLoadingLoadingComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoadingComponent", function () {
      return LoadingComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var LoadingComponent = function LoadingComponent() {
      _classCallCheck(this, LoadingComponent);
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], LoadingComponent.prototype, "condition", void 0);
    LoadingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-loading',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./loading.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/loading/loading.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./loading.component.scss */
      "./src/app/loading/loading.component.scss")).default]
    })], LoadingComponent);
    /***/
  },

  /***/
  "./src/app/login/login.component.scss":
  /*!********************************************!*\
    !*** ./src/app/login/login.component.scss ***!
    \********************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoginLoginComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "header {\n  position: relative;\n  background-color: #04af74 !important;\n  height: 100px;\n}\n\nimg {\n  height: 100%;\n  padding: 0;\n  margin: 0;\n}\n\nheader h1 {\n  position: absolute;\n  color: white;\n  font-size: 25px;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.row {\n  height: calc(100% - 100px);\n  width: 100%;\n  margin: 0px;\n}\n\n.back_3 {\n  background-image: url('back_3.jpg');\n  background-repeat: repeat;\n  background-size: cover;\n}\n\n.form-wrap {\n  text-align: center;\n  background: url('login.jpg'), rgba(255, 255, 255, 0.3);\n  background-blend-mode: color-dodge;\n  background-size: cover;\n  border-radius: 10%;\n  width: 60%;\n  height: 80%;\n  margin-top: 10px;\n  padding: 5% 5%;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.form-wrap .input-wrap {\n  margin: 5px 0;\n}\n\n.form-wrap .mat-form-field {\n  width: 100%;\n}\n\nh1 {\n  color: #3867d5;\n  font-size: 46px;\n}\n\np > span {\n  color: #3867d5;\n  font-size: 18px;\n}\n\nh4 {\n  margin-top: 20px;\n}\n\np {\n  text-align: left !important;\n  margin-bottom: 5px;\n}\n\n.mat-form-field-wrapper::after {\n  padding-bottom: 0px !important;\n}\n\n.warning-div {\n  position: fixed;\n  padding: 15px;\n  background-color: #49a3f2;\n  color: white;\n  top: 0;\n  width: 100%;\n  z-index: 100;\n  text-align: center;\n  font-size: 20px;\n}\n\n.warning-button {\n  border-radius: 4px;\n  background-color: white;\n  border: none;\n  padding: 3px 8px;\n  float: right;\n}\n\n.cancel_button {\n  padding: 5px 12px;\n  border: none;\n  border-radius: 4px;\n  background-color: #e62c22;\n  float: right;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vRTpcXHByb2plY3RzXFxOb2RlK0FuZ3VsYXJcXGZvb3RiYWxsIGJldHRpbmcgc2l0ZVxcZnJvbnQgZW5kIG9mZmkgd2lmYmFsbCAyXFxmcm9udCBlbmQvc3JjXFxhcHBcXGxvZ2luXFxsb2dpbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLG9DQUFBO0VBQ0EsYUFBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx3Q0FBQTtVQUFBLGdDQUFBO0FDQ0o7O0FERUE7RUFDSSwwQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxtQ0FBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBUUEsc0RBQUE7RUFLQSxrQ0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFFQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx3Q0FBQTtVQUFBLGdDQUFBO0FDWEo7O0FEWkk7RUFDSSxhQUFBO0FDY1I7O0FEWkk7RUFDSSxXQUFBO0FDY1I7O0FEU0E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQ05KOztBRFNBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUNOSjs7QURTQTtFQUNJLGdCQUFBO0FDTko7O0FEU0E7RUFDSSwyQkFBQTtFQUNBLGtCQUFBO0FDTko7O0FEU0E7RUFDSSw4QkFBQTtBQ05KOztBRFNBO0VBQ0ksZUFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNOSjs7QURTQTtFQUNJLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FDTko7O0FEU0E7RUFDSSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUNOSiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaGVhZGVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYig0LCAxNzUsIDExNikhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxufVxyXG5cclxuaW1nIHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbmhlYWRlciBoMSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG59XHJcblxyXG4ucm93IHtcclxuICAgIGhlaWdodDogY2FsYygxMDAlIC0gMTAwcHgpO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW46IDBweDtcclxufVxyXG5cclxuLmJhY2tfMyB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9iYWNrXzMuanBnJyk7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuLmZvcm0td3JhcCB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAuaW5wdXQtd3JhcCB7XHJcbiAgICAgICAgbWFyZ2luOiA1cHggMDtcclxuICAgIH1cclxuICAgIC5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbiAgICAvLyBwYWRkaW5nOiAyMCU7XHJcbiAgICBiYWNrZ3JvdW5kOnVybCgnLi4vLi4vYXNzZXRzL2xvZ2luLmpwZycpLFxyXG4gICAgcmdiKDI1NSxcclxuICAgIDI1NSxcclxuICAgIDI1NSxcclxuICAgIDAuMyk7XHJcbiAgICBiYWNrZ3JvdW5kLWJsZW5kLW1vZGU6IGNvbG9yLWRvZGdlO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwJTtcclxuICAgIC8vIG9wYWNpdHk6IDAuNztcclxuICAgIHdpZHRoOjYwJTtcclxuICAgIGhlaWdodDo4MCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgcGFkZGluZzo1JSA1JTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSxcclxuICAgIC01MCUpO1xyXG59XHJcblxyXG5oMSB7XHJcbiAgICBjb2xvcjogcmdiKDU2LCAxMDMsIDIxMyk7XHJcbiAgICBmb250LXNpemU6IDQ2cHg7XHJcbn1cclxuXHJcbnA+c3BhbiB7XHJcbiAgICBjb2xvcjogcmdiKDU2LCAxMDMsIDIxMyk7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcbmg0IHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbnAge1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdCFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbn1cclxuXHJcbi5tYXQtZm9ybS1maWVsZC13cmFwcGVyOjphZnRlciB7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMHB4IWltcG9ydGFudDtcclxufVxyXG5cclxuLndhcm5pbmctZGl2IHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDlhM2YyO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB6LWluZGV4OiAxMDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuXHJcbi53YXJuaW5nLWJ1dHRvbiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIHBhZGRpbmc6IDNweCA4cHg7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbn1cclxuXHJcbi5jYW5jZWxfYnV0dG9uIHtcclxuICAgIHBhZGRpbmc6IDVweCAxMnB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2MmMyMjtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufSIsImhlYWRlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzA0YWY3NCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG5pbWcge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMDtcbn1cblxuaGVhZGVyIGgxIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG5cbi5yb3cge1xuICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDEwMHB4KTtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbjogMHB4O1xufVxuXG4uYmFja18zIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2JhY2tfMy5qcGdcIik7XG4gIGJhY2tncm91bmQtcmVwZWF0OiByZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi5mb3JtLXdyYXAge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJhY2tncm91bmQ6IHVybChcIi4uLy4uL2Fzc2V0cy9sb2dpbi5qcGdcIiksIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4zKTtcbiAgYmFja2dyb3VuZC1ibGVuZC1tb2RlOiBjb2xvci1kb2RnZTtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogMTAlO1xuICB3aWR0aDogNjAlO1xuICBoZWlnaHQ6IDgwJTtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgcGFkZGluZzogNSUgNSU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG4uZm9ybS13cmFwIC5pbnB1dC13cmFwIHtcbiAgbWFyZ2luOiA1cHggMDtcbn1cbi5mb3JtLXdyYXAgLm1hdC1mb3JtLWZpZWxkIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbmgxIHtcbiAgY29sb3I6ICMzODY3ZDU7XG4gIGZvbnQtc2l6ZTogNDZweDtcbn1cblxucCA+IHNwYW4ge1xuICBjb2xvcjogIzM4NjdkNTtcbiAgZm9udC1zaXplOiAxOHB4O1xufVxuXG5oNCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbnAge1xuICB0ZXh0LWFsaWduOiBsZWZ0ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbn1cblxuLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXI6OmFmdGVyIHtcbiAgcGFkZGluZy1ib3R0b206IDBweCAhaW1wb3J0YW50O1xufVxuXG4ud2FybmluZy1kaXYge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHBhZGRpbmc6IDE1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICM0OWEzZjI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdG9wOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgei1pbmRleDogMTAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLndhcm5pbmctYnV0dG9uIHtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyOiBub25lO1xuICBwYWRkaW5nOiAzcHggOHB4O1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi5jYW5jZWxfYnV0dG9uIHtcbiAgcGFkZGluZzogNXB4IDEycHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTYyYzIyO1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiB3aGl0ZTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/login/login.component.ts":
  /*!******************************************!*\
    !*** ./src/app/login/login.component.ts ***!
    \******************************************/

  /*! exports provided: LoginComponent */

  /***/
  function srcAppLoginLoginComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginComponent", function () {
      return LoginComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _shared_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../shared/auth.service */
    "./src/app/shared/auth.service.ts");

    var LoginComponent =
    /*#__PURE__*/
    function () {
      function LoginComponent(auth, formBuilder, router, activatedRoute) {
        _classCallCheck(this, LoginComponent);

        this.auth = auth;
        this.formBuilder = formBuilder;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.isLoading = false;
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('');
        this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('');
        this.pageIn = 1;
        this.warning = false;
      }

      _createClass(LoginComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.verifyId = localStorage.getItem('verify');
          console.log(this.verifyId);
          this.activatedRoute.queryParams.subscribe(function (params) {
            console.log(" this is the verifyId..........");
            console.log(_this.verifyId);

            if (params['verify']) {
              _this.verifyId = params['verify'];
              localStorage.setItem('verify', params['verify']);
              console.log(params['verify']);
              _this.warning = true;
              _this.warning_message = 'Your accont is confirmed, you can now login';

              _this.auth.confirmEmail(params['verify']);
            } else {
              if (_this.verifyId === 'need') {
                _this.warning = true;
                _this.warning_message = 'Please confirm your account an email has been sent to you';
              }
            }
          });
          this.isLoading = true; // if (this.auth.loggedIn) {
          //   this.router.navigate(['/']);
          // }

          this.loginForm = this.formBuilder.group({
            email: this.email,
            password: this.password
          });
          this.pageIn = 1;
        }
      }, {
        key: "resolved",
        value: function resolved(captchaResponse) {
          this.recaptcha = captchaResponse;
          console.log(this.recaptcha);
        }
      }, {
        key: "login",
        value: function login() {
          // this.auth.signIn(this.loginForm.value);
          if (!this.recaptcha) {
            alert('You have to check robot verifycation');
          } else {
            if (this.verifyId === 'need') {
              this.warning = true;
              this.warning_message = 'Please confirm your account an email has been sent to you';
            } else {
              console.log(this.loginForm.value);
              this.auth.signIn(this.loginForm.value);
            }
          }
        }
      }, {
        key: "closeWarningbutton",
        value: function closeWarningbutton() {
          this.warning = false;
          this.warning_message = '';
        }
      }]);

      return LoginComponent;
    }();

    LoginComponent.ctorParameters = function () {
      return [{
        type: _shared_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }];
    };

    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-login',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./login.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./login.component.scss */
      "./src/app/login/login.component.scss")).default]
    })], LoginComponent);
    /***/
  },

  /***/
  "./src/app/main/main.component.scss":
  /*!******************************************!*\
    !*** ./src/app/main/main.component.scss ***!
    \******************************************/

  /*! exports provided: default */

  /***/
  function srcAppMainMainComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "body {\n  font-family: \"babool\" !important;\n}\n\nheader {\n  width: 100%;\n  height: 180px;\n}\n\n.main_header {\n  background-image: url('banner.png');\n  background-repeat: no-repeat;\n  background-size: 100% 150%;\n  background-position: bottom;\n  position: relative;\n}\n\nheader > div > img {\n  position: absolute;\n  width: 200px;\n  height: auto;\n  top: 60px;\n  left: 10px;\n}\n\nfooter {\n  width: 100%;\n  bottom: 0;\n}\n\nfooter > .message {\n  width: 100%;\n  padding: 20px 20px 0px 20px;\n  background-color: #14374b;\n}\n\nfooter > .black {\n  width: 100%;\n  margin: 0;\n  height: 40px;\n  background-color: black;\n  color: white;\n  font-size: 22px;\n}\n\n.current {\n  background-color: #14374b;\n  padding-top: 10px;\n}\n\n.darkblue {\n  background-color: #14374b !important;\n}\n\n.simplegreen {\n  background-color: #2e7211 !important;\n}\n\n.simplegreen {\n  background-color: #2e7211 !important;\n}\n\n.lightblue {\n  background-color: #0a867f !important;\n}\n\n#number_remain {\n  border: 12px solid #7ed957;\n  background-color: white;\n  border-radius: 6px;\n  padding: auto;\n  padding-bottom: 4px;\n  width: 80%;\n  margin: auto;\n  padding-top: 4px;\n}\n\n#remain_subscription {\n  border: 12px solid #14374b;\n  background-color: white;\n  border-radius: 6px;\n  padding: auto;\n  padding-bottom: 4px;\n  padding-top: 4px;\n  width: 80%;\n  margin: auto;\n  color: red;\n}\n\n.photo_img {\n  height: 90px;\n  width: 90px;\n  border-radius: 50%;\n  background-color: darkgray;\n  border: 2px solid white;\n}\n\n.subpart {\n  background-color: #0e5b60;\n  padding: 5px;\n  margin-bottom: 10px;\n}\n\n.content {\n  margin-top: 20px;\n  min-height: 480px;\n  max-height: 600px;\n  overflow: scroll;\n}\n\ninput {\n  color: #14374b;\n}\n\n.back_white {\n  background-color: transparent;\n  padding: 5px 0;\n  height: 50px;\n}\n\n.back_white::after {\n  content: \" \";\n  clear: both;\n  display: table;\n}\n\n.header-div-line {\n  float: left;\n  width: 40%;\n}\n\n.select-room {\n  float: left;\n  width: 20%;\n  color: white;\n}\n\n.top-bar-line {\n  margin-top: 18px;\n  width: 100%;\n  border-top: 3px solid white;\n}\n\n.button-group {\n  margin: 20px;\n}\n\n.received-button {\n  background-color: green;\n  color: white;\n  padding: 6px 20px;\n  border-radius: 6px;\n  border: none;\n}\n\n.subscribers-button {\n  background-color: #e62c22;\n  color: white;\n  padding: 6px 20px;\n  border-radius: 6px;\n  border: none;\n}\n\n.main-chatroom-button {\n  background-color: darkslategray;\n  color: white;\n  padding: 6px 20px;\n  border-radius: 6px;\n  border: none;\n  margin: 0 100px;\n}\n\n.upload_button {\n  background-color: #49a3f2;\n  font-size: 12px;\n  padding: 6px 20px;\n  color: white;\n  border-radius: 6px;\n  border: none;\n}\n\n.counter-div {\n  background-color: white;\n  color: black;\n  border-radius: 6px;\n  width: 80%;\n  padding: 6px 0;\n}\n\n.remaing-day-div {\n  background-color: white;\n  color: red;\n  border-radius: 6px;\n  width: 30%;\n  padding: 0;\n  margin: auto;\n}\n\n.subscription-button {\n  margin-top: 10px;\n  background-color: orange;\n  color: white;\n  font-size: 14px;\n  padding: 5px 0;\n  width: 70%;\n  border-radius: 8px;\n  border: none;\n}\n\n.sub-photo-img {\n  width: 65px;\n  height: 65px;\n  border-radius: 50%;\n  background-color: grey;\n  border: 2px solid white;\n}\n\n.span-div {\n  background-color: white;\n  border-radius: 4px;\n  padding: 0 45px;\n  color: black;\n  margin-left: 15px;\n}\n\n.answer-button {\n  background-color: green;\n  color: white;\n  font-size: 16px;\n  width: 80%;\n  padding: 10px 0;\n  border: none;\n  border-radius: 8px;\n}\n\n.discover-button {\n  background-color: #49a3f2;\n  border-radius: 4px;\n  border: none;\n  margin-left: 10px;\n  padding: 3px 16px;\n  color: white;\n}\n\n.send-button {\n  background-color: #49a3f2;\n  color: white;\n  border-radius: 8px;\n  border: none;\n  height: 80px;\n  text-align: center;\n  font-size: 16px;\n  width: 85%;\n  margin: auto;\n  float: right;\n}\n\n.back-green-div {\n  background-color: lightgreen;\n  color: white;\n  border-radius: 8px;\n  height: 40px;\n  padding-left: 20px;\n  padding-top: 7px;\n  width: 250px;\n  float: right;\n}\n\n.active-border {\n  border: 2px solid white;\n}\n\n.row {\n  margin: 0;\n}\n\n.warning-div {\n  position: fixed;\n  padding: 15px;\n  background-color: white;\n  color: green;\n  top: 0;\n  width: 100%;\n  z-index: 100;\n  text-align: center;\n  font-size: 20px;\n}\n\n.warning-button {\n  border-radius: 4px;\n  background-color: white;\n  border: none;\n  padding: 3px 8px;\n  float: right;\n}\n\n.cancel_button {\n  padding: 5px 12px;\n  border: none;\n  border-radius: 4px;\n  background-color: #e62c22;\n  float: right;\n  color: white;\n}\n\n.answer_button {\n  padding: 5px 12px;\n  border: none;\n  border-radius: 4px;\n  background-color: green;\n  float: right;\n  color: white;\n  margin-right: 15px;\n}\n\n.goto_pay {\n  padding: 7px 18px;\n  background-color: orange;\n  color: white;\n  border-radius: 8px;\n  border: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi9FOlxccHJvamVjdHNcXE5vZGUrQW5ndWxhclxcZm9vdGJhbGwgYmV0dGluZyBzaXRlXFxmcm9udCBlbmQgb2ZmaSB3aWZiYWxsIDJcXGZyb250IGVuZC9zcmNcXGFwcFxcbWFpblxcbWFpbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvbWFpbi9tYWluLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUtBO0VBQ0ksZ0NBQUE7QUNKSjs7QURPQTtFQUNJLFdBQUE7RUFFQSxhQUFBO0FDTEo7O0FEUUE7RUFDSSxtQ0FBQTtFQUNBLDRCQUFBO0VBRUEsMEJBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0FDTko7O0FEU0E7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUNOSjs7QURTQTtFQUVJLFdBQUE7RUFDQSxTQUFBO0FDUEo7O0FEVUE7RUFDSSxXQUFBO0VBRUEsMkJBQUE7RUFDQSx5QkF4Q2lCO0FDZ0NyQjs7QURXQTtFQUNJLFdBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUNSSjs7QURXQTtFQUNJLHlCQXJEaUI7RUFzRGpCLGlCQUFBO0FDUko7O0FEWUE7RUFDSSxvQ0FBQTtBQ1RKOztBRFlBO0VBQ0ksb0NBQUE7QUNUSjs7QURZQTtFQUNJLG9DQUFBO0FDVEo7O0FEWUE7RUFDSSxvQ0FBQTtBQ1RKOztBRFlBO0VBQ0ksMEJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ1RKOztBRGFBO0VBQ0ksMEJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFFQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUNYSjs7QURjQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQkFBQTtFQUNBLHVCQUFBO0FDWEo7O0FEY0E7RUFDSSx5QkE3R2M7RUE4R2QsWUFBQTtFQUNBLG1CQUFBO0FDWEo7O0FEY0E7RUFDSSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQ1hKOztBRGVBO0VBQ0ksY0ExSGlCO0FDOEdyQjs7QURnQkE7RUFDSSw2QkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FDYko7O0FEZ0JBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0FDYko7O0FEZ0JBO0VBQ0ksV0FBQTtFQUNBLFVBQUE7QUNiSjs7QURnQkE7RUFDSSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUNiSjs7QURnQkE7RUFDSSxnQkFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtBQ2JKOztBRGdCQTtFQUNJLFlBQUE7QUNiSjs7QURnQkE7RUFDSSx1QkFBQTtFQUNBLFlBQUE7RUFFQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQ2RKOztBRGlCQTtFQUNJLHlCQUFBO0VBQ0EsWUFBQTtFQUVBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDZko7O0FEa0JBO0VBQ0ksK0JBQUE7RUFDQSxZQUFBO0VBRUEsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FDaEJKOztBRG1CQTtFQUNJLHlCQUFBO0VBRUEsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQ2pCSjs7QURvQkE7RUFDSSx1QkFBQTtFQUNBLFlBQUE7RUFFQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0FDbEJKOztBRHFCQTtFQUNJLHVCQUFBO0VBQ0EsVUFBQTtFQUVBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FDbkJKOztBRHNCQTtFQUNJLGdCQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDbkJKOztBRHVCQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FDcEJKOztBRHVCQTtFQUNJLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDcEJKOztBRHVCQTtFQUNJLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFFQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ3JCSjs7QUR3QkE7RUFDSSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FDckJKOztBRHlCQTtFQUNJLHlCQUFBO0VBRUEsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUN2Qko7O0FEMEJBO0VBQ0ksNEJBQUE7RUFDQSxZQUFBO0VBRUEsa0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FDeEJKOztBRDJCQTtFQUNJLHVCQUFBO0FDeEJKOztBRDJCQTtFQUNJLFNBQUE7QUN4Qko7O0FEMkJBO0VBQ0ksZUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUN4Qko7O0FEMkJBO0VBQ0ksa0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUN4Qko7O0FEMkJBO0VBQ0ksaUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FDeEJKOztBRDJCQTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDeEJKOztBRDJCQTtFQUNJLGlCQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDeEJKIiwiZmlsZSI6InNyYy9hcHAvbWFpbi9tYWluLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gJGZvbnQtc3RhY2s6ICAgIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbiR3aWYtZ3JlZW4tY29sb3I6IHJnYigxNCwgOTEsIDk2KTtcbiR3aWYtZGFya2JsdWUtY29sb3I6IHJnYigyMCwgNTUsIDc1KTtcbiR3aWYtbGlnaHRibHVlLWNvbG9yOiByZ2IoMTAsIDEzNCwgMTI3KTtcbiR3aWYtc2ltcGxlZ3JlZW4tY29sb3I6IHJnYig0NiwgMTE0LCAxNyk7XG5ib2R5IHtcbiAgICBmb250LWZhbWlseTogXCJiYWJvb2xcIiAhaW1wb3J0YW50O1xufVxuXG5oZWFkZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8vIHBhZGRpbmctYm90dG9tOiAyMHB4O1xuICAgIGhlaWdodDogMTgwcHg7XG59XG5cbi5tYWluX2hlYWRlciB7XG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvYmFubmVyLnBuZycpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgLy8gYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTUwJTtcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBib3R0b207XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG5oZWFkZXI+ZGl2PmltZyB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgdG9wOiA2MHB4O1xuICAgIGxlZnQ6IDEwcHg7XG59XG5cbmZvb3RlciB7XG4gICAgLy8gcG9zaXRpb246IGZpeGVkO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvdHRvbTogMDtcbn1cblxuZm9vdGVyPi5tZXNzYWdlIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICAvLyBoZWlnaHQ6IDI0MHB4O1xuICAgIHBhZGRpbmc6IDIwcHggMjBweCAwcHggMjBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkd2lmLWRhcmtibHVlLWNvbG9yO1xufVxuXG5mb290ZXI+LmJsYWNrIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW46IDA7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDIycHg7XG59XG5cbi5jdXJyZW50IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkd2lmLWRhcmtibHVlLWNvbG9yO1xuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xuICAgIC8vIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG4uZGFya2JsdWUge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICR3aWYtZGFya2JsdWUtY29sb3IgIWltcG9ydGFudDtcbn1cblxuLnNpbXBsZWdyZWVuIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkd2lmLXNpbXBsZWdyZWVuLWNvbG9yICFpbXBvcnRhbnQ7XG59XG5cbi5zaW1wbGVncmVlbiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHdpZi1zaW1wbGVncmVlbi1jb2xvciAhaW1wb3J0YW50O1xufVxuXG4ubGlnaHRibHVlIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkd2lmLWxpZ2h0Ymx1ZS1jb2xvciAhaW1wb3J0YW50O1xufVxuXG4jbnVtYmVyX3JlbWFpbiB7XG4gICAgYm9yZGVyOiAxMnB4IHNvbGlkIHJnYigxMjYsIDIxNywgODcpO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgICBwYWRkaW5nOiBhdXRvO1xuICAgIHBhZGRpbmctYm90dG9tOiA0cHg7XG4gICAgd2lkdGg6IDgwJTtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgcGFkZGluZy10b3A6IDRweDtcbiAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbn1cblxuI3JlbWFpbl9zdWJzY3JpcHRpb24ge1xuICAgIGJvcmRlcjogMTJweCBzb2xpZCAkd2lmLWRhcmtibHVlLWNvbG9yO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgICBwYWRkaW5nOiBhdXRvO1xuICAgIHBhZGRpbmctYm90dG9tOiA0cHg7XG4gICAgcGFkZGluZy10b3A6IDRweDtcbiAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbiAgICB3aWR0aDogODAlO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBjb2xvcjogcmVkO1xufVxuXG4ucGhvdG9faW1nIHtcbiAgICBoZWlnaHQ6IDkwcHg7XG4gICAgd2lkdGg6IDkwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJhY2tncm91bmQtY29sb3I6IGRhcmtncmF5O1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xufVxuXG4uc3VicGFydCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHdpZi1ncmVlbi1jb2xvcjtcbiAgICBwYWRkaW5nOiA1cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuLmNvbnRlbnQge1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgbWluLWhlaWdodDogNDgwcHg7XG4gICAgbWF4LWhlaWdodDogNjAwcHg7XG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgICAvLyBvdmVyZmxvdy15OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbmlucHV0IHtcbiAgICBjb2xvcjogJHdpZi1kYXJrYmx1ZS1jb2xvcjtcbn1cblxuLy8gYnkgZnRmIC8vXG4uYmFja193aGl0ZSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgcGFkZGluZzogNXB4IDA7XG4gICAgaGVpZ2h0OiA1MHB4O1xufVxuXG4uYmFja193aGl0ZTo6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6IFwiIFwiO1xuICAgIGNsZWFyOiBib3RoO1xuICAgIGRpc3BsYXk6IHRhYmxlO1xufVxuXG4uaGVhZGVyLWRpdi1saW5lIHtcbiAgICBmbG9hdDogbGVmdDtcbiAgICB3aWR0aDogNDAlO1xufVxuXG4uc2VsZWN0LXJvb20ge1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIHdpZHRoOiAyMCU7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG4udG9wLWJhci1saW5lIHtcbiAgICBtYXJnaW4tdG9wOiAxOHB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvcmRlci10b3A6IDNweCBzb2xpZCB3aGl0ZTtcbn1cblxuLmJ1dHRvbi1ncm91cCB7XG4gICAgbWFyZ2luOiAyMHB4O1xufVxuXG4ucmVjZWl2ZWQtYnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgLy8gZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZzogNnB4IDIwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xuICAgIGJvcmRlcjogbm9uZTtcbn1cblxuLnN1YnNjcmliZXJzLWJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2MmMyMjtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgLy8gZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZzogNnB4IDIwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xuICAgIGJvcmRlcjogbm9uZTtcbn1cblxuLm1haW4tY2hhdHJvb20tYnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBkYXJrc2xhdGVncmF5O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA2cHggMjBweDtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIG1hcmdpbjogMCAxMDBweDtcbn1cblxuLnVwbG9hZF9idXR0b24ge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM0OWEzZjI7XG4gICAgLy8gZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIHBhZGRpbmc6IDZweCAyMHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgYm9yZGVyOiBub25lO1xufVxuXG4uY291bnRlci1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIGNvbG9yOiBibGFjaztcbiAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgd2lkdGg6IDgwJTtcbiAgICBwYWRkaW5nOiA2cHggMDtcbn1cblxuLnJlbWFpbmctZGF5LWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgY29sb3I6IHJlZDtcbiAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBwYWRkaW5nOiAwO1xuICAgIG1hcmdpbjogYXV0bztcbn1cblxuLnN1YnNjcmlwdGlvbi1idXR0b24ge1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogb3JhbmdlO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgcGFkZGluZzogNXB4IDA7XG4gICAgd2lkdGg6IDcwJTtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4uc3ViLXBob3RvLWltZyB7XG4gICAgd2lkdGg6IDY1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmV5O1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xufVxuXG4uc3Bhbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICBwYWRkaW5nOiAwIDQ1cHg7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xufVxuXG4uYW5zd2VyLWJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW47XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbiAgICB3aWR0aDogODAlO1xuICAgIHBhZGRpbmc6IDEwcHggMDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xufVxuXG4uZGlzY292ZXItYnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDlhM2YyO1xuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgcGFkZGluZzogM3B4IDE2cHg7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4uc2VuZC1idXR0b24ge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM0OWEzZjI7XG4gICAgLy8gZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgd2lkdGg6IDg1JTtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uYmFjay1ncmVlbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JlZW47XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAyMHB4O1xuICAgIHBhZGRpbmctdG9wOiA3cHg7XG4gICAgd2lkdGg6IDI1MHB4O1xuICAgIGZsb2F0OiByaWdodDtcbn1cblxuLmFjdGl2ZS1ib3JkZXIge1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xufVxuXG4ucm93IHtcbiAgICBtYXJnaW46IDA7XG59XG5cbi53YXJuaW5nLWRpdiB7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgY29sb3I6IGdyZWVuO1xuICAgIHRvcDogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICB6LWluZGV4OiAxMDA7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLndhcm5pbmctYnV0dG9uIHtcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHBhZGRpbmc6IDNweCA4cHg7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uY2FuY2VsX2J1dHRvbiB7XG4gICAgcGFkZGluZzogNXB4IDEycHg7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTYyYzIyO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbi5hbnN3ZXJfYnV0dG9uIHtcbiAgICBwYWRkaW5nOiA1cHggMTJweDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xufVxuXG4uZ290b19wYXkge1xuICAgIHBhZGRpbmc6IDdweCAxOHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJvcmRlcjogbm9uZTtcbn1cblxuLy8gLmZvb3Rlcl9kaXYge1xuLy8gICAgIHBvc2l0aW9uOiBmaXhlZDtcbi8vICAgICBib3R0b206IDA7XG4vLyAgICAgd2lkdGg6IDEwMCU7XG4vLyB9IiwiYm9keSB7XG4gIGZvbnQtZmFtaWx5OiBcImJhYm9vbFwiICFpbXBvcnRhbnQ7XG59XG5cbmhlYWRlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE4MHB4O1xufVxuXG4ubWFpbl9oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvYmFubmVyLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDE1MCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGJvdHRvbTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG5oZWFkZXIgPiBkaXYgPiBpbWcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAyMDBweDtcbiAgaGVpZ2h0OiBhdXRvO1xuICB0b3A6IDYwcHg7XG4gIGxlZnQ6IDEwcHg7XG59XG5cbmZvb3RlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3R0b206IDA7XG59XG5cbmZvb3RlciA+IC5tZXNzYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDIwcHggMjBweCAwcHggMjBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE0Mzc0Yjtcbn1cblxuZm9vdGVyID4gLmJsYWNrIHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbjogMDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDIycHg7XG59XG5cbi5jdXJyZW50IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE0Mzc0YjtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG59XG5cbi5kYXJrYmx1ZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxNDM3NGIgIWltcG9ydGFudDtcbn1cblxuLnNpbXBsZWdyZWVuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJlNzIxMSAhaW1wb3J0YW50O1xufVxuXG4uc2ltcGxlZ3JlZW4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmU3MjExICFpbXBvcnRhbnQ7XG59XG5cbi5saWdodGJsdWUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGE4NjdmICFpbXBvcnRhbnQ7XG59XG5cbiNudW1iZXJfcmVtYWluIHtcbiAgYm9yZGVyOiAxMnB4IHNvbGlkICM3ZWQ5NTc7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIHBhZGRpbmc6IGF1dG87XG4gIHBhZGRpbmctYm90dG9tOiA0cHg7XG4gIHdpZHRoOiA4MCU7XG4gIG1hcmdpbjogYXV0bztcbiAgcGFkZGluZy10b3A6IDRweDtcbn1cblxuI3JlbWFpbl9zdWJzY3JpcHRpb24ge1xuICBib3JkZXI6IDEycHggc29saWQgIzE0Mzc0YjtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogYXV0bztcbiAgcGFkZGluZy1ib3R0b206IDRweDtcbiAgcGFkZGluZy10b3A6IDRweDtcbiAgd2lkdGg6IDgwJTtcbiAgbWFyZ2luOiBhdXRvO1xuICBjb2xvcjogcmVkO1xufVxuXG4ucGhvdG9faW1nIHtcbiAgaGVpZ2h0OiA5MHB4O1xuICB3aWR0aDogOTBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBkYXJrZ3JheTtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG59XG5cbi5zdWJwYXJ0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzBlNWI2MDtcbiAgcGFkZGluZzogNXB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuXG4uY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIG1pbi1oZWlnaHQ6IDQ4MHB4O1xuICBtYXgtaGVpZ2h0OiA2MDBweDtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cblxuaW5wdXQge1xuICBjb2xvcjogIzE0Mzc0Yjtcbn1cblxuLmJhY2tfd2hpdGUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgcGFkZGluZzogNXB4IDA7XG4gIGhlaWdodDogNTBweDtcbn1cblxuLmJhY2tfd2hpdGU6OmFmdGVyIHtcbiAgY29udGVudDogXCIgXCI7XG4gIGNsZWFyOiBib3RoO1xuICBkaXNwbGF5OiB0YWJsZTtcbn1cblxuLmhlYWRlci1kaXYtbGluZSB7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogNDAlO1xufVxuXG4uc2VsZWN0LXJvb20ge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDIwJTtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4udG9wLWJhci1saW5lIHtcbiAgbWFyZ2luLXRvcDogMThweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci10b3A6IDNweCBzb2xpZCB3aGl0ZTtcbn1cblxuLmJ1dHRvbi1ncm91cCB7XG4gIG1hcmdpbjogMjBweDtcbn1cblxuLnJlY2VpdmVkLWJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDZweCAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLnN1YnNjcmliZXJzLWJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlNjJjMjI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogNnB4IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4ubWFpbi1jaGF0cm9vbS1idXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBkYXJrc2xhdGVncmF5O1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDZweCAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgbWFyZ2luOiAwIDEwMHB4O1xufVxuXG4udXBsb2FkX2J1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM0OWEzZjI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgcGFkZGluZzogNnB4IDIwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5jb3VudGVyLWRpdiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBjb2xvcjogYmxhY2s7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgd2lkdGg6IDgwJTtcbiAgcGFkZGluZzogNnB4IDA7XG59XG5cbi5yZW1haW5nLWRheS1kaXYge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgY29sb3I6IHJlZDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICB3aWR0aDogMzAlO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5zdWJzY3JpcHRpb24tYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogb3JhbmdlO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgcGFkZGluZzogNXB4IDA7XG4gIHdpZHRoOiA3MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4uc3ViLXBob3RvLWltZyB7XG4gIHdpZHRoOiA2NXB4O1xuICBoZWlnaHQ6IDY1cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogZ3JleTtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG59XG5cbi5zcGFuLWRpdiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIHBhZGRpbmc6IDAgNDVweDtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogMTVweDtcbn1cblxuLmFuc3dlci1idXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHdpZHRoOiA4MCU7XG4gIHBhZGRpbmc6IDEwcHggMDtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG59XG5cbi5kaXNjb3Zlci1idXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDlhM2YyO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmc6IDNweCAxNnB4O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5zZW5kLWJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM0OWEzZjI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBib3JkZXI6IG5vbmU7XG4gIGhlaWdodDogODBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHdpZHRoOiA4NSU7XG4gIG1hcmdpbjogYXV0bztcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uYmFjay1ncmVlbi1kaXYge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyZWVuO1xuICBjb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHBhZGRpbmctdG9wOiA3cHg7XG4gIHdpZHRoOiAyNTBweDtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uYWN0aXZlLWJvcmRlciB7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xufVxuXG4ucm93IHtcbiAgbWFyZ2luOiAwO1xufVxuXG4ud2FybmluZy1kaXYge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHBhZGRpbmc6IDE1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBjb2xvcjogZ3JlZW47XG4gIHRvcDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIHotaW5kZXg6IDEwMDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi53YXJuaW5nLWJ1dHRvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIGJvcmRlcjogbm9uZTtcbiAgcGFkZGluZzogM3B4IDhweDtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uY2FuY2VsX2J1dHRvbiB7XG4gIHBhZGRpbmc6IDVweCAxMnB4O1xuICBib3JkZXI6IG5vbmU7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2MmMyMjtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5hbnN3ZXJfYnV0dG9uIHtcbiAgcGFkZGluZzogNXB4IDEycHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbn1cblxuLmdvdG9fcGF5IHtcbiAgcGFkZGluZzogN3B4IDE4cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcbiAgY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGJvcmRlcjogbm9uZTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/main/main.component.ts":
  /*!****************************************!*\
    !*** ./src/app/main/main.component.ts ***!
    \****************************************/

  /*! exports provided: MainComponent */

  /***/
  function srcAppMainMainComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MainComponent", function () {
      return MainComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _shared_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../shared/auth.service */
    "./src/app/shared/auth.service.ts");
    /* harmony import */


    var _webchat_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../webchat.service */
    "./src/app/webchat.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ng2-file-upload */
    "./node_modules/ng2-file-upload/fesm2015/ng2-file-upload.js");

    var URL = 'http://192.162.69.178:3000/auth/upload';

    var MainComponent =
    /*#__PURE__*/
    function () {
      // the varables for active and deactive the buttons
      function MainComponent(authService, route, webchatService) {
        var _this2 = this;

        _classCallCheck(this, MainComponent);

        this.authService = authService;
        this.route = route;
        this.webchatService = webchatService;
        this.imagePath = 'http://192.162.69.178:3000/images';
        this.user_id = this.authService.getCurrentUserId();
        this.bonus = false;
        this.messageArray = [];
        this.responseArray = [];
        this.postArray = [];
        this.blockusers = null;
        this.warning = false;
        this.warning_message = "";
        this.answer_value = false;
        this.subscribers = 0;
        this.resonse_received = 0;
        this.cur_id = '';
        this.cur_userId = '';
        this.cur_status = false;
        this.cur_img_state = 0; //refresh event

        this.click_refresh = 0; // online users

        this.onlineusers = 1; // count send answers

        this.send_answer_accounts = [];
        this.removeId = false;
        this.uploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_5__["FileUploader"]({
          url: URL,
          itemAlias: 'photo'
        }); // online users

        this.webchatService.onlineusers().subscribe(function (data) {
          console.log('..this is the online use counters...');
          console.log(data);
          _this2.onlineusers = data.counters;
          console.log(_this2.onlineusers);

          if (_this2.onlineusers < 1) {
            _this2.onlineusers = 1;
          }
        });
        this.webchatService.newMessageReceived().subscribe(function (data) {
          console.log('..get the current new message...');
          console.log(data);

          _this2.messageArray.push(data);

          console.log(_this2.messageArray);
        });
        this.webchatService.newSubscribePost().subscribe(function (data) {
          console.log('..get the current new subscriber...');
          console.log(data);

          if (data.userId == _this2.currentUser.msg._id) {// this.subscribers++;
          }
        });
        this.webchatService.newUnsubscribePost().subscribe(function (data) {
          console.log('..get the current new unscriber...');
          console.log(data);

          if (data.userId == _this2.currentUser.msg._id) {// this.subscribers--;
          }
        });
        this.webchatService.newAnswer().subscribe(function (data) {
          console.log('..get the new answer...');
          console.log(data.client);
          console.log(_this2.currentUser.msg._id);

          if (data.client == _this2.currentUser.msg._id) {
            _this2.responseArray.push(data);

            _this2.resonse_received++;
            console.log('...this is my received message...');
            console.log(_this2.responseArray);
          }

          console.log(data);
        });
      }

      _createClass(MainComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this3 = this;

          // this.blockusers = [];
          this.click_refresh = 0; // to prevent the robot message - onint values

          this.robot_last_recorded_time = parseInt(localStorage.getItem('robot_last_recorded_time'));
          this.robot_first_recorded_time = parseInt(localStorage.getItem('robot_first_recorded_time'));
          this.robot_ruletime = parseInt(localStorage.getItem('robot_ruletime'));

          if (Date.now() - this.robot_first_recorded_time > this.robot_ruletime) {
            this.robot_time_interval = 60000;
            this.robot_number = 5;
            this.robot_count = 0;
          } else {
            this.robot_time_interval = parseInt(localStorage.getItem('robot_time_interval'));
            this.robot_number = parseInt(localStorage.getItem('robot_number'));
            this.robot_count = parseInt(localStorage.getItem('robot_count'));
          }

          this.message = null;
          this.videoLink = null;
          this.message_id = null;
          this.relative_id = null;
          this.relative_email = null;
          this.click_event;
          this.cur_photoUrl = '';
          this.cur_name = '';
          this.cur_message = '';
          this.cur_videoLink = '';
          this.cur_useremail = '';
          this.cur_id = '';
          this.cur_userId = '';
          this.cur_status = false;
          this.cur_img_state = 0;
          this.warning = false;
          this.warning_message = "";
          this.send_answer_accounts = [];
          this.removeId = false;

          if (localStorage.getItem('pageName') === null) {
            this.pageName = 'main';
          } else {
            this.pageName = localStorage.getItem('pageName');
          }

          this.currentUser = this.authService.getCurrentUser(); // check the user online

          console.log('... I am online users...');
          this.webchatService.iamonline(this.currentUser.msg._id);
          var currentTime = Date.now();
          console.log("... this is the current time ...");
          console.log(currentTime);
          console.log("... this is the expired time....");
          console.log(this.currentUser.msg.res_day);

          if (currentTime < this.currentUser.msg.res_day) {
            this.remaining_days = Math.round((this.currentUser.msg.res_day - currentTime) / 1000 / 86400).toString();
            this.bonus = true;
          } else {
            this.remaining_days = '-';
            this.bonus = false;
          }

          if (!this.currentUser.msg.photoUrl || this.currentUser.msg.photoUrl == null || this.currentUser.msg.img_state === 0) {
            this.imgURL = '/assets/image/login.jpg';
          } else {
            this.imgURL = "".concat(this.imagePath, "/").concat(this.currentUser.msg.photoUrl);
          } // get the subscribers


          this.authService.getMySubscribers().subscribe(function (data) {
            console.log("this is the my subscribers...");
            console.log(data);

            if (data === null || data === '') {// this.subscribers = 0;
            } else {// this.subscribers = parseInt(data.re);
              }
          }); // get the messageArray (for main chatroom)

          this.authService.getChatRoomsMessage().subscribe(function (data) {
            console.log("this is the chat room message...");
            _this3.messageArray = data;
            console.log(_this3.messageArray);

            if (_this3.messageArray.length > 0) {
              for (var i = 0; i < _this3.messageArray.length; i++) {
                if (_this3.messageArray[i].followers.find(function (x) {
                  return x.useremail === _this3.currentUser.msg.email;
                })) {
                  if (_this3.messageArray[i].followers.find(function (x) {
                    return x.state === 0;
                  })) {
                    _this3.postArray.push(_this3.messageArray[i]);

                    _this3.subscribers++;
                  }
                }

                if (_this3.messageArray[i].comments.find(function (x) {
                  return x.comment_user === _this3.currentUser.msg.email;
                })) {
                  console.log("...remove this message because you have already read before...");
                  console.log(_this3.messageArray[i]._id); // this.messageArray = this.messageArray.filter(item => item._id === this.messageArray[i]._id);

                  _this3.messageArray.splice(i, 1);
                }
              }
            }
          }); // get the block users

          this.authService.getBlockUsers().subscribe(function (data) {
            console.log(data);
            console.log("...this is the block users...");
            _this3.blockusers = data;
            console.log(data);
          }); // get the response received (for the Response received)

          this.authService.getResponseReceived().subscribe(function (data) {
            console.log("this is the resonse receieved message...");
            console.log(data);
            data.forEach(function (val) {
              var flag = 0;

              if (_this3.blockusers !== null && _this3.blockusers.blockId.length > 0) {
                for (var i = 0; i < _this3.blockusers.blockId.length; i++) {
                  if (_this3.blockusers.blockId[i] === val.owner) {
                    flag = 1;
                  }
                }
              }

              if (flag === 0) {
                for (var j = 0; j < val.answer.length; j++) {
                  console.log("This is the answer order in response..." + j);
                  console.log(val.answer[j]);
                  var inval_answer = [];
                  inval_answer.push(val.answer[j]);
                  var inval = {
                    message_id: val.message_id,
                    owner: val.owner,
                    client: val.client,
                    relative: val.relative,
                    answer_state: val.answer_state,
                    answer: inval_answer,
                    userdetail: val.userdetail
                  };
                  console.log(inval.answer.length);
                  _this3.resonse_received++;

                  _this3.responseArray.push(inval);
                } // this.resonse_received = this.resonse_received + val.answer.length;
                // this.responseArray.push(val);

              }
            });
          }); // upload image file for photo

          this.uploader.onAfterAddingFile = function (file) {
            file.withCredentials = false;
          };

          this.uploader.onCompleteItem = function (item, response, status, headers) {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this3, void 0, void 0,
            /*#__PURE__*/
            regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      if (!(this.currentUser.msg.img_state == 1)) {
                        _context.next = 7;
                        break;
                      }

                      _context.next = 3;
                      return this.authService.updateUserImage(this.user_id, JSON.parse(response).fileName);

                    case 3:
                      this.currentUser.msg.photoUrl = JSON.parse(response).fileName;
                      localStorage.setItem('current_user', JSON.stringify(this.currentUser));
                      _context.next = 9;
                      break;

                    case 7:
                      this.warning = true;
                      this.warning_message = 'You can not upload profile image because of block';

                    case 9:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          };
        } // block warning message

      }, {
        key: "blockwarning",
        value: function blockwarning() {
          this.warning = true;
          this.warning_message = 'You can not upload image because of block.';
        } // preview the uploaded image

      }, {
        key: "preview",
        value: function preview(files) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee2() {
            var _this4 = this;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.authService.getUserimg().subscribe(function (data) {
                      console.log(data);
                      console.log(data.imgre);

                      if (data.imgre) {
                        if (files.length === 0) {
                          return;
                        }

                        var mimeType = files[0].type;

                        if (mimeType.match(/image\/*/) == null) {
                          return;
                        }

                        var reader = new FileReader();
                        _this4.imagePath = files;
                        reader.readAsDataURL(files[0]);

                        reader.onload = function (_event) {
                          _this4.imgURL = reader.result;
                        };
                      } else {
                        _this4.warning = true;
                        _this4.warning_message = 'You can not upload image because of block';
                        _this4.currentUser.msg.img_state = 0;
                        _this4.imgURL = '/assets/image/login.jpg';
                      }
                    });

                  case 2:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        } // logout

      }, {
        key: "logout",
        value: function logout() {
          this.webchatService.offline(this.currentUser.msg._id);
          this.authService.doLogout();
        } // send the message

      }, {
        key: "MessageSend",
        value: function MessageSend() {
          var _this5 = this;

          this.bonus = true;
          var noyoutube = false;
          console.log("..this is the video link...");
          console.log(this.videoLink);

          if (this.bonus) {
            console.log('****************this.bonus****************', this.bonus);

            if (this.videoLink !== null && this.videoLink !== '') {
              var link = this.videoLink.split(".")[1];
              console.log('this is youtube link' + link);

              if (link !== 'youtube') {
                noyoutube = true;
              }
            } else {
              this.videoLink = null;
            }
          } else {
            this.videoLink = null;
          }

          if ((this.message === '' || this.message == null) && this.videoLink == null || noyoutube) {
            if (noyoutube) {
              this.warning = true;
              this.warning_message = 'Youtube (Links) "only valid"';
            } else {
              this.warning = true;
              this.warning_message = 'No message entered "Please enter your messages to receive notifications"';
            }
          } else {
            // send answer
            if (this.message_id !== '' && this.relative_id != null) {
              console.log('..remove this message from messageArray...');
              console.log(this.message_id);
              console.log(this.messageArray);
              console.log(this.relative_email);
              this.messageArray = this.messageArray.filter(function (item) {
                return item._id !== _this5.message_id;
              });
              console.log('..remove this message from postArray...');

              if (this.pageName === 'subscriber' || this.pageName === 'main') {
                var postIndex = 0;

                if (this.send_answer_accounts.length > 0) {
                  for (var i = 0; i < this.send_answer_accounts.length; i++) {
                    if (this.send_answer_accounts[i].id === this.message_id) {
                      this.send_answer_accounts[i].times++;

                      if (this.send_answer_accounts[i].times > 1) {
                        postIndex = i;
                        this.removeId = true;
                      }
                    }
                  }

                  if (postIndex === 0) {
                    var data = {
                      id: this.message_id,
                      times: 1
                    };
                    this.send_answer_accounts.push(data);
                  } else {
                    this.postArray = this.postArray.filter(function (item) {
                      return item._id !== _this5.message_id;
                    });
                    this.send_answer_accounts = this.send_answer_accounts.filter(function (item) {
                      return item.id !== _this5.message_id;
                    });
                  }
                } else {
                  var _data = {
                    id: this.message_id,
                    times: 1
                  };
                  this.send_answer_accounts.push(_data);
                }
              }

              this.webchatService.sendAnswer({
                message_id: this.message_id,
                id: this.user_id,
                current_user: this.currentUser.msg.email,
                to_user_email: this.relative_email,
                userId: this.relative_id,
                message: this.message,
                videoLink: this.videoLink,
                removeId: this.removeId
              });

              if (this.pageName === 'response' && this.message_id !== '' && this.relative_id !== '') {
                console.log('..this is the answer of response...');
                console.log(this.message_id);
                console.log(this.responseArray);
                console.log(this.responseArray);
              }

              this.message = '';
              this.videoLink = '';
              this.answer_value = false;
              this.message_id = '';
              this.relative_id = '';
              this.relative_email = '';
              this.closelookingmore();
            } else {
              if (this.pageName == 'main' && (this.message_id !== '' || this.message_id !== null)) {
                // get the current time and compare the value
                var curtime = Date.now();

                if (curtime - this.robot_last_recorded_time < this.robot_time_interval) {
                  this.warning = true;
                  this.warning_message = 'Restriction "please wait" ' + (this.robot_time_interval / 1000).toString() + ' "secondes between each post message" ';
                } else {
                  // check the perhour
                  if (curtime - this.robot_first_recorded_time > this.robot_ruletime) {
                    this.robot_last_recorded_time = curtime;
                    this.robot_first_recorded_time = 0; // this.robot_ruletime = 3600000;

                    this.robot_time_interval = 60000; // this.robot_number = 5;

                    this.robot_count = 0;
                  } else {
                    this.robot_count++;
                    this.robot_last_recorded_time = curtime;

                    if (this.robot_count === 1) {
                      this.robot_first_recorded_time = curtime;
                    }

                    if (this.robot_count > this.robot_number) {
                      this.robot_time_interval = 60000 * ((this.robot_count - this.robot_count % 5) / 5 + 1) + Math.floor(Math.random() * 7) * 1000;
                    }

                    console.log(' this is the time interval...');
                    console.log('this is the count message...');
                    console.log(this.robot_count);
                    console.log(this.robot_time_interval);
                  }

                  localStorage.setItem('robot_last_recorded_time', this.robot_last_recorded_time);
                  localStorage.setItem('robot_first_recorded_time', this.robot_first_recorded_time);
                  localStorage.setItem('robot_time_interval', this.robot_time_interval);
                  localStorage.setItem('robot_count', this.robot_count);

                  if (this.message_id === '' || this.relative_id == null) {
                    this.webchatService.sendMessage({
                      userId: this.currentUser.msg._id,
                      user: this.currentUser.msg.pseduo,
                      useremail: this.currentUser.msg.email,
                      photoUrl: this.currentUser.msg.photoUrl,
                      message: this.message,
                      videoLink: this.videoLink
                    });
                    this.message = '';
                    this.videoLink = '';
                    this.answer_value = false;
                    this.message_id = '';
                    this.relative_id = '';
                    this.relative_email = '';
                    this.closelookingmore();
                  } else {// this.webchatService.sendAnswer({
                    //   message_id: this.message_id,
                    //   id: this.user_id,
                    //   current_user: this.currentUser.msg.email,
                    //   to_user_email: this.relative_email,
                    //   userId: this.relative_id,
                    //   message: this.message,
                    //   videoLink: this.videoLink
                    // });
                    // console.log('..remove this message from messageArray...');
                    // console.log(this.message_id);
                    // console.log(this.messageArray);
                    // console.log(this.relative_email);
                    // this.messageArray = this.messageArray.filter( item => item._id !== this.message_id);
                    // console.log('..remove this message from postArray...');
                    // console.log(this.postArray);
                    // this.postArray = this.postArray.filter( item => item._id !== this.message_id );
                  }
                }
              }
            }
          }
        } // remove the messageArray

      }, {
        key: "refreshMessage",
        value: function refreshMessage() {
          var _this6 = this;

          console.log(" this is  the refresh double click event..");
          this.click_refresh++;

          if (this.click_refresh == 1) {
            this.warning = true;
            this.warning_message = 'Double click to confirm "delete entire message history"';
            setTimeout(function () {
              console.log('Test');
              _this6.click_refresh = 0;
            }, 3000);
          }

          if (this.click_refresh == 2) {
            this.message = '';
            this.videoLink = '';
            this.message_id = '';
            this.relative_id = '';
            this.messageArray = [];
            this.responseArray = [];
            this.postArray = [];
            this.answer_value = false;
            this.subscribers = 0;
            this.resonse_received = 0;
            this.authService.messageRefresh(this.currentUser.msg._id);
            this.click_refresh = 0;
          }
        } // page change

      }, {
        key: "pageChange",
        value: function pageChange(req) {
          if (req !== 'main') {
            this.cur_photoUrl = '';
            this.cur_name = '';
            this.cur_message = '';
            this.cur_videoLink = '';
            this.cur_useremail = '';
            this.cur_id = '';
            this.cur_userId = '';
            this.cur_status = false;
            this.cur_img_state = 0;
          }

          if (req === 'response' && this.bonus === false) {
            this.warning = true;
            this.warning_message = 'Restricted room "reserved for subscribers"';
            this.pageName = 'getSub';
          } else {
            this.pageName = req;
          }

          console.log(this.pageName);
          localStorage.setItem('pageName', this.pageName);
        } // subscribe the post

      }, {
        key: "subscribePost",
        value: function subscribePost(message_id, userId, video_id, name) {
          var _this7 = this;

          if (this.pageName === 'response') {
            this.webchatService.subscribePost({
              message_id: message_id,
              email: this.currentUser.msg.email,
              subscriberId: userId,
              userId: this.currentUser.msg._id,
              videoId: video_id
            });
            this.warning = true;
            this.warning_message = "You now follow all the messages posted by " + name;
          } else {
            if (this.messageArray.length > 0) {
              var flag = 0;
              var result = this.messageArray.find(function (x) {
                return x._id == message_id;
              });
              console.log("...check the follows...");
              console.log(result);

              if (result.follows > 0) {
                if (result.followers.find(function (x) {
                  return x.useremail === _this7.currentUser.msg.email;
                })) {
                  console.log("..there is the exist alreay..");
                  console.log(this.currentUser.msg.email);
                  flag = 1;
                }
              }

              if (flag == 0) {
                this.messageArray.forEach(function (val) {
                  if (val._id === message_id) {
                    var data = {
                      useremail: _this7.currentUser.msg.email,
                      state: 0
                    };
                    val.followers.push(data);
                    val.follows++;

                    _this7.postArray.push(val);
                  }
                });
                console.log(this.messageArray);
                this.webchatService.subscribePost({
                  message_id: message_id,
                  email: this.currentUser.msg.email,
                  subscriberId: userId,
                  userId: this.currentUser.msg._id,
                  videoId: video_id
                });
                this.warning = true;
                this.warning_message = 'You now follow all the messages posted by "' + name + '"';
                this.subscribers++;
              } else {
                this.warning = true;
                this.warning_message = 'You are already subscribed to the messages posted by "' + name + '"';
              }
            }
          }
        } // unsubscribe the post

      }, {
        key: "unsubscribePost",
        value: function unsubscribePost(message_id, userId, name) {
          var _this8 = this;

          if (this.postArray.length > 0) {
            this.postArray.forEach(function (val, index) {
              if (val._id == message_id) {
                _this8.postArray.splice(index, 1);
              }
            });
            this.messageArray.forEach(function (val, index) {
              if (val._id == message_id) {
                val.followers.forEach(function (vall, ind) {
                  if (vall.useremail == _this8.currentUser.msg.email) {
                    console.log(ind);
                    val.followers.splice(ind, 1);
                  }
                });
                val.follows--;
              }
            });
            this.webchatService.unsubscribePost({
              message_id: message_id,
              email: this.currentUser.msg.email,
              userId: this.currentUser.msg._id,
              subscriberId: userId
            });
            this.warning = true;
            this.warning_message = "You no longer follow the messages of " + name;
            this.subscribers--;

            if (this.subscribers < 0) {
              this.subscribers = 0;
            }
          }
        } // close the warning button

      }, {
        key: "closeWarningbutton",
        value: function closeWarningbutton() {
          this.warning = false;
          this.warning_message = "";
        } // ----------- about the answer part ----------------//
        // add the answer form

      }, {
        key: "openTextarea",
        value: function openTextarea(message_id, userId, useremail) {
          this.answer_value = true;
          this.message_id = message_id;
          this.relative_id = userId;
          this.relative_email = useremail;
          console.log(this.message_id);
          console.log(this.relative_id);
          console.log(this.relative_email);
        } // cancel answer

      }, {
        key: "answerCancel",
        value: function answerCancel() {
          this.answer_value = false;
          this.message_id = '';
          this.relative_id = '';
          this.message = '';
          this.videoLink = '';
          console.log(this.message_id);
          console.log(this.relative_id);
        } // get the subscription page

      }, {
        key: "getSubscriptionPage",
        value: function getSubscriptionPage() {
          console.log('*******************getSubscriptionPage*****************');
          this.pageName = 'getSub';
        } // looking the choice user's message

      }, {
        key: "lookingmore",
        value: function lookingmore(cur_photoUrl, cur_name, cur_message, cur_videoLink, cur_useremail, cur_id, cur_userId, cur_img_state) {
          console.log(cur_message);
          this.cur_photoUrl = cur_photoUrl;
          this.cur_name = cur_name;
          this.cur_message = cur_message;
          this.cur_videoLink = cur_videoLink;
          this.cur_useremail = cur_useremail;
          this.cur_id = cur_id;
          this.cur_userId = cur_userId;
          this.cur_status = true;
          this.relative_email = cur_useremail;
          this.cur_img_state = cur_img_state;
        } // close the choice user's message

      }, {
        key: "closelookingmore",
        value: function closelookingmore() {
          this.cur_photoUrl = '';
          this.cur_name = '';
          this.cur_message = '';
          this.cur_videoLink = '';
          this.cur_useremail = '';
          this.cur_id = '';
          this.cur_userId = '';
          this.cur_status = false;
        } // blocking message(user)

      }, {
        key: "message_block",
        value: function message_block(userId) {
          console.log(userId);
          alert("Are you sure you want to block responses from this user");
          this.webchatService.messageblock({
            clientId: userId,
            userId: this.currentUser.msg._id
          });
          this.responseArray = this.responseArray.filter(function (x) {
            return x.owner !== userId;
          });
          window.location.reload();
        } // unblocking message(user)

      }, {
        key: "message_unblock",
        value: function message_unblock(userId) {
          console.log(userId);
          alert("Are you sure you want to unblock this user's replies 'press a second time to validate'");
          this.webchatService.messageunblock({
            clientId: userId,
            userId: this.currentUser.msg._id
          });
          window.location.reload();
        } // when the input the video link, check the bouns

      }, {
        key: "checklink",
        value: function checklink() {
          if (!this.bonus) {
            this.warning = true;
            this.warning_message = 'Restricted Youtube links  "reserved for Wifball subscribers"';
          }
        }
      }]);

      return MainComponent;
    }();

    MainComponent.ctorParameters = function () {
      return [{
        type: _shared_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
      }, {
        type: _webchat_service__WEBPACK_IMPORTED_MODULE_3__["WebchatService"]
      }];
    };

    MainComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-main',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./main.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./main.component.scss */
      "./src/app/main/main.component.scss")).default]
    })], MainComponent);
    /***/
  },

  /***/
  "./src/app/material/material.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/material/material.module.ts ***!
    \*********************************************/

  /*! exports provided: MaterialModule */

  /***/
  function srcAppMaterialMaterialModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MaterialModule", function () {
      return MaterialModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/cdk/table */
    "./node_modules/@angular/cdk/esm2015/table.js");
    /* harmony import */


    var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/cdk/overlay */
    "./node_modules/@angular/cdk/esm2015/overlay.js");
    /* harmony import */


    var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/material */
    "./node_modules/@angular/material/esm2015/material.js");
    /*
     * This module imports and re-exports all Angular Material modules for convenience,
     * so only 1 module import is needed in your feature modules.
     * See https://material.angular.io/guide/getting-started#step-3-import-the-component-modules.
     *
     * To optimize your production builds, you should only import the components used in your app.
     */


    var MaterialModule = function MaterialModule() {
      _classCallCheck(this, MaterialModule);
    };

    MaterialModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      exports: [// CDK
      _angular_cdk_table__WEBPACK_IMPORTED_MODULE_2__["CdkTableModule"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_3__["OverlayModule"], // Material
      _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatAutocompleteModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatButtonModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatButtonToggleModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatCardModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatCheckboxModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatChipsModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatDatepickerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatDialogModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatExpansionModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatGridListModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatIconModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatInputModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatListModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatMenuModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatProgressBarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatProgressSpinnerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatRadioModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatRippleModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSelectModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSidenavModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSlideToggleModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSliderModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSnackBarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTabsModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatToolbarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTooltipModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatNativeDateModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatFormFieldModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatStepperModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatPaginatorModule"], _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatProgressSpinnerModule"]]
    })], MaterialModule);
    /***/
  },

  /***/
  "./src/app/privacy/privacy.component.scss":
  /*!************************************************!*\
    !*** ./src/app/privacy/privacy.component.scss ***!
    \************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPrivacyPrivacyComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByaXZhY3kvcHJpdmFjeS5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/privacy/privacy.component.ts":
  /*!**********************************************!*\
    !*** ./src/app/privacy/privacy.component.ts ***!
    \**********************************************/

  /*! exports provided: PrivacyComponent */

  /***/
  function srcAppPrivacyPrivacyComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PrivacyComponent", function () {
      return PrivacyComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var PrivacyComponent =
    /*#__PURE__*/
    function () {
      function PrivacyComponent() {
        _classCallCheck(this, PrivacyComponent);
      }

      _createClass(PrivacyComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return PrivacyComponent;
    }();

    PrivacyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-privacy',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./privacy.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/privacy/privacy.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./privacy.component.scss */
      "./src/app/privacy/privacy.component.scss")).default]
    })], PrivacyComponent);
    /***/
  },

  /***/
  "./src/app/register/register.component.scss":
  /*!**************************************************!*\
    !*** ./src/app/register/register.component.scss ***!
    \**************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRegisterRegisterComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "header {\n  position: relative;\n  background-color: #04af74 !important;\n  height: 100px;\n}\n\nimg {\n  height: 100%;\n  padding: 0;\n  margin: 0;\n}\n\nheader h1 {\n  position: absolute;\n  color: white;\n  font-size: 25px;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.row {\n  height: calc(100% - 100px);\n  width: 100%;\n  margin: 0px;\n}\n\n.back_3 {\n  background-image: url('back_3.jpg');\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n\n.form-wrap {\n  text-align: center;\n  background: url('register.jpg'), rgba(255, 255, 255, 0.3);\n  background-blend-mode: lighten;\n  background-size: cover;\n  border-radius: 10%;\n  width: 60%;\n  height: 80%;\n  padding: 5% 5%;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.form-wrap .input-wrap {\n  margin: 5px 0;\n}\n\n.form-wrap .mat-form-field {\n  width: 100%;\n}\n\nh1 {\n  color: #3867d5;\n  font-size: 46px;\n}\n\n.mat-form-field-wrapper {\n  padding-bottom: 0px !important;\n}\n\n.warning-div {\n  position: fixed;\n  padding: 15px;\n  background-color: #49a3f2;\n  color: white;\n  top: 0;\n  width: 100%;\n  z-index: 100;\n  text-align: center;\n  font-size: 20px;\n}\n\n.warning-button {\n  border-radius: 4px;\n  background-color: white;\n  border: none;\n  padding: 3px 8px;\n  float: right;\n}\n\n.cancel_button {\n  padding: 5px 12px;\n  border: none;\n  border-radius: 4px;\n  background-color: #e62c22;\n  float: right;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIvRTpcXHByb2plY3RzXFxOb2RlK0FuZ3VsYXJcXGZvb3RiYWxsIGJldHRpbmcgc2l0ZVxcZnJvbnQgZW5kIG9mZmkgd2lmYmFsbCAyXFxmcm9udCBlbmQvc3JjXFxhcHBcXHJlZ2lzdGVyXFxyZWdpc3Rlci5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcmVnaXN0ZXIvcmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLG9DQUFBO0VBQ0EsYUFBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx3Q0FBQTtVQUFBLGdDQUFBO0FDQ0o7O0FERUE7RUFDSSwwQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxtQ0FBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBUUEseURBQUE7RUFLQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFFQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0Esd0NBQUE7VUFBQSxnQ0FBQTtBQ1hKOztBRFhJO0VBQ0ksYUFBQTtBQ2FSOztBRFhJO0VBQ0ksV0FBQTtBQ2FSOztBRFNBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUNOSjs7QURTQTtFQUNJLDhCQUFBO0FDTko7O0FEVUE7RUFDSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ1BKOztBRFVBO0VBQ0ksa0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUNQSjs7QURVQTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQ1BKIiwiZmlsZSI6InNyYy9hcHAvcmVnaXN0ZXIvcmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoZWFkZXIge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDQsIDE3NSwgMTE2KSFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG59XHJcblxyXG5pbWcge1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuaGVhZGVyIGgxIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbn1cclxuXHJcbi5yb3cge1xyXG4gICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAxMDBweCk7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG59XHJcblxyXG4uYmFja18zIHtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2JhY2tfMy5qcGcnKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG59XHJcblxyXG4uZm9ybS13cmFwIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIC5pbnB1dC13cmFwIHtcclxuICAgICAgICBtYXJnaW46IDVweCAwO1xyXG4gICAgfVxyXG4gICAgLm1hdC1mb3JtLWZpZWxkIHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIC8vIHBhZGRpbmc6IDIwJTtcclxuICAgIGJhY2tncm91bmQ6dXJsKCcuLi8uLi9hc3NldHMvcmVnaXN0ZXIuanBnJyksXHJcbiAgICByZ2IoMjU1LFxyXG4gICAgMjU1LFxyXG4gICAgMjU1LFxyXG4gICAgMC4zKTtcclxuICAgIGJhY2tncm91bmQtYmxlbmQtbW9kZTogbGlnaHRlbjtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMCU7XHJcbiAgICAvLyBvcGFjaXR5OiAwLjc7XHJcbiAgICB3aWR0aDo2MCU7XHJcbiAgICBoZWlnaHQ6ODAlO1xyXG4gICAgcGFkZGluZzo1JSA1JTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSxcclxuICAgIC01MCUpO1xyXG59XHJcblxyXG5oMSB7XHJcbiAgICBjb2xvcjogcmdiKDU2LCAxMDMsIDIxMyk7XHJcbiAgICBmb250LXNpemU6IDQ2cHg7XHJcbn1cclxuXHJcbi5tYXQtZm9ybS1maWVsZC13cmFwcGVyIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAwcHghaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuLndhcm5pbmctZGl2IHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDlhM2YyO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB6LWluZGV4OiAxMDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuXHJcbi53YXJuaW5nLWJ1dHRvbiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIHBhZGRpbmc6IDNweCA4cHg7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbn1cclxuXHJcbi5jYW5jZWxfYnV0dG9uIHtcclxuICAgIHBhZGRpbmc6IDVweCAxMnB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2MmMyMjtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4iLCJoZWFkZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJhY2tncm91bmQtY29sb3I6ICMwNGFmNzQgIWltcG9ydGFudDtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cblxuaW1nIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG59XG5cbmhlYWRlciBoMSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDI1cHg7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xufVxuXG4ucm93IHtcbiAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW46IDBweDtcbn1cblxuLmJhY2tfMyB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9iYWNrXzMuanBnXCIpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4uZm9ybS13cmFwIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvcmVnaXN0ZXIuanBnXCIpLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMyk7XG4gIGJhY2tncm91bmQtYmxlbmQtbW9kZTogbGlnaHRlbjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogMTAlO1xuICB3aWR0aDogNjAlO1xuICBoZWlnaHQ6IDgwJTtcbiAgcGFkZGluZzogNSUgNSU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG4uZm9ybS13cmFwIC5pbnB1dC13cmFwIHtcbiAgbWFyZ2luOiA1cHggMDtcbn1cbi5mb3JtLXdyYXAgLm1hdC1mb3JtLWZpZWxkIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbmgxIHtcbiAgY29sb3I6ICMzODY3ZDU7XG4gIGZvbnQtc2l6ZTogNDZweDtcbn1cblxuLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXIge1xuICBwYWRkaW5nLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi53YXJuaW5nLWRpdiB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgcGFkZGluZzogMTVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzQ5YTNmMjtcbiAgY29sb3I6IHdoaXRlO1xuICB0b3A6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICB6LWluZGV4OiAxMDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ud2FybmluZy1idXR0b24ge1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBib3JkZXI6IG5vbmU7XG4gIHBhZGRpbmc6IDNweCA4cHg7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLmNhbmNlbF9idXR0b24ge1xuICBwYWRkaW5nOiA1cHggMTJweDtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlNjJjMjI7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6IHdoaXRlO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/register/register.component.ts":
  /*!************************************************!*\
    !*** ./src/app/register/register.component.ts ***!
    \************************************************/

  /*! exports provided: RegisterComponent */

  /***/
  function srcAppRegisterRegisterComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterComponent", function () {
      return RegisterComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _shared_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../shared/auth.service */
    "./src/app/shared/auth.service.ts");

    var EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    var RegisterComponent =
    /*#__PURE__*/
    function () {
      function RegisterComponent(auth, formBuilder, router) {
        _classCallCheck(this, RegisterComponent);

        this.auth = auth;
        this.formBuilder = formBuilder;
        this.router = router;
        this.isLoading = false;
        this.warning = false;
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern(EMAIL_REGEX)]);
        this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(6)]);
        this.name = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('');
        this.pseduo = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('');
      }

      _createClass(RegisterComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.warning = false;
          this.warning_message = '';
          this.isLoading = true; // if (this.auth.loggedIn) {
          //   this.router.navigate(['/']);
          // }
          // this.addRecaptchaScript();

          this.registerForm = this.formBuilder.group({
            name: this.name,
            email: this.email,
            pseduo: this.pseduo,
            password: this.password
          });
        }
      }, {
        key: "closeWarningbutton",
        value: function closeWarningbutton() {
          this.warning = false;
          this.warning_message = '';
        }
      }, {
        key: "resolved",
        value: function resolved(captchaResponse) {
          this.recaptcha = captchaResponse;
          console.log(this.recaptcha);
        }
      }, {
        key: "register",
        value: function register() {
          var _this9 = this;

          console.log(this.registerForm.value); // this.auth.signUp(this.registerForm.value).subscribe((res) => {
          //     if (res.result) {
          //       console.log(res);
          //       this.registerForm.reset();
          //       this.router.navigate(['login']);
          //     }
          //     if (res.error) {
          //       this.warning = true;
          //       this.warning_message = "Sing up Error! The account is already registered. \n please sign up another email.";
          //       console.log("you need to resiger again");
          //     }
          //     // this.router.navigate(['login']);
          //   });

          if (!this.recaptcha) {
            alert('You have to check robot verifycation');
          } else {
            this.auth.signUp(this.registerForm.value).subscribe(function (res) {
              if (res.result) {
                console.log(res);

                _this9.registerForm.reset(); // localStorage.setItem('verify', 'need');


                _this9.router.navigate(['login']);
              }

              if (res.error) {
                console.log(res.error);
                _this9.warning = true;

                if (res.error.hasOwnProperty('name')) {
                  _this9.warning_message = 'Name already used "please specify another one"';
                } else {
                  if (res.error.hasOwnProperty('email')) {
                    _this9.warning_message = 'E-mail already used "please specify another one"';
                  } else {
                    if (res.error.hasOwnProperty('pseduo')) {
                      _this9.warning_message = 'Nickname already used "please specify another one"';
                    } else {
                      _this9.warning_message = 'Registration error "please follow the instructions to complete the registration"';
                    }
                  }
                }

                console.log("you need to resiger again");
              } // this.router.navigate(['login']);

            });
          }
        }
      }]);

      return RegisterComponent;
    }();

    RegisterComponent.ctorParameters = function () {
      return [{
        type: _shared_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }];
    };

    RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-register',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./register.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html")).default,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./register.component.scss */
      "./src/app/register/register.component.scss")).default]
    })], RegisterComponent);
    /***/
  },

  /***/
  "./src/app/shared/auth.guard.ts":
  /*!**************************************!*\
    !*** ./src/app/shared/auth.guard.ts ***!
    \**************************************/

  /*! exports provided: AuthGuard */

  /***/
  function srcAppSharedAuthGuardTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthGuard", function () {
      return AuthGuard;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AuthGuard =
    /*#__PURE__*/
    function () {
      function AuthGuard() {
        _classCallCheck(this, AuthGuard);
      }

      _createClass(AuthGuard, [{
        key: "canActivate",
        value: function canActivate(next, state) {
          return true;
        }
      }]);

      return AuthGuard;
    }();

    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AuthGuard);
    /***/
  },

  /***/
  "./src/app/shared/auth.service.ts":
  /*!****************************************!*\
    !*** ./src/app/shared/auth.service.ts ***!
    \****************************************/

  /*! exports provided: AuthService */

  /***/
  function srcAppSharedAuthServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthService", function () {
      return AuthService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js"); // import * as io from "socket.io-client";


    var AuthService =
    /*#__PURE__*/
    function () {
      function AuthService(http, router) {
        _classCallCheck(this, AuthService);

        this.http = http;
        this.router = router; // startpoint: string = 'https://vps67203.lws-hosting.com';
        // endpoint: string = 'https://vps67203.lws-hosting.com/auth';
        // startpoint: string = 'http://localhost:3000';
        // endpoint: string = 'http://localhost:3000/auth';

        this.startpoint = 'http://192.162.69.178:3000';
        this.endpoint = 'http://192.162.69.178:3000/auth'; // endpoint: string = 'http://localhost:3000/auth';

        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Content-Type', 'application/json');
        this.uri = "ws://192.162.69.178:3000";
      } // Sign-up


      _createClass(AuthService, [{
        key: "signUp",
        value: function signUp(user) {
          var api = "".concat(this.endpoint, "/register-user");
          return this.http.post(api, user).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
        } // Sign-in

      }, {
        key: "signIn",
        value: function signIn(user) {
          var _this10 = this;

          console.log(user);
          return this.http.post("".concat(this.endpoint, "/signin"), user).subscribe(function (res) {
            console.log(res);

            if (res.error || res.noconfirm) {
              console.log("you need to verify");
              alert('Wrong user account. please login correct');
            } else {
              localStorage.setItem('access_token', res.token); // this.emit('user name added',res._id);

              _this10.getUserProfile(res._id).subscribe(function (res) {
                _this10.currentUser = res; // for the time invterval message

                localStorage.setItem('robot_last_recorded_time', '0');
                localStorage.setItem('robot_first_recorded_time', '0');
                localStorage.setItem('robot_ruletime', '3600000');
                localStorage.setItem('robot_time_interval', '60000');
                localStorage.setItem('robot_number', '5');
                localStorage.setItem('robot_count', '0');
                localStorage.setItem('current_user', JSON.stringify(res));
                localStorage.setItem('user_id', JSON.stringify(res.msg._id));

                _this10.router.navigate(['main/' + res.msg._id]); // this.router.navigateByUrl('main']);

              });
            }
          });
        } // forget

      }, {
        key: "forget",
        value: function forget(email) {
          var _this11 = this;

          return this.http.post("".concat(this.endpoint, "/forget"), email).subscribe(function (res) {
            // localStorage.setItem('access_token', res.token)
            // this.emit('user name added',res._id);
            _this11.getUser_Profile(res._id).subscribe(function (res) {
              _this11.currentUser = res; // this.router.navigateByUrl('main']);
            });
          });
        }
      }, {
        key: "update",
        value: function update(user) {
          var _this12 = this;

          return this.http.post("".concat(this.endpoint, "/updatePassword"), user).subscribe(function (res) {
            // localStorage.setItem('access_token', res.token)
            // this.emit('user name added',res._id);
            _this12.router.navigate(['login']);
          });
        }
      }, {
        key: "getToken",
        value: function getToken() {
          return localStorage.getItem('access_token');
        }
      }, {
        key: "doLogout",
        value: function doLogout() {
          var removeToken = localStorage.removeItem('access_token');

          if (removeToken == null) {
            localStorage.clear();
            this.router.navigate(['login']);
          }
        } // User profile

      }, {
        key: "getUserProfile",
        value: function getUserProfile(id) {
          var api = "".concat(this.endpoint, "/user-profile/").concat(id);
          return this.http.get(api, {
            headers: this.headers
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            return res || {};
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
        }
      }, {
        key: "getUser_Profile",
        value: function getUser_Profile(id) {
          var api = "".concat(this.endpoint, "/userProfile/").concat(id);
          return this.http.get(api, {
            headers: this.headers
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            return res || {};
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
        } // Error

      }, {
        key: "handleError",
        value: function handleError(error) {
          var msg = '';

          if (error.error instanceof ErrorEvent) {
            // client-side error
            msg = error.error.message;
          } else {
            // server-side error
            msg = "Error Code: ".concat(error.status, "\nMessage: ").concat(error.message);
          }

          return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(msg);
        } // get the current user

      }, {
        key: "getCurrentUser",
        value: function getCurrentUser() {
          this.currentUser = JSON.parse(localStorage.getItem('current_user'));
          return this.currentUser;
        } // get the current user id

      }, {
        key: "getCurrentUserId",
        value: function getCurrentUserId() {
          return JSON.parse(localStorage.getItem('user_id'));
        } // update the user image path

      }, {
        key: "updateUserImage",
        value: function updateUserImage(user_id, imageName) {
          var api = "".concat(this.endpoint, "/photo/").concat(user_id, "/").concat(imageName);
          return this.http.get(api, {
            headers: this.headers
          }).subscribe(function (res) {
            console.log(res);
          });
        } // get all chatrooms messages

      }, {
        key: "getChatRoomsMessage",
        value: function getChatRoomsMessage() {
          var api = "".concat(this.startpoint, "/chatroom/").concat(this.currentUser.msg._id);
          return this.http.get(api);
        } // get the response received

      }, {
        key: "getResponseReceived",
        value: function getResponseReceived() {
          var api = "".concat(this.startpoint, "/response/").concat(this.currentUser.msg._id);
          return this.http.get(api);
        } // get the subscribe received

      }, {
        key: "getMySubscribers",
        value: function getMySubscribers() {
          var api = "".concat(this.startpoint, "/subscribe/").concat(this.currentUser.msg._id);
          return this.http.get(api);
        } // update myinfo for subscription 15

      }, {
        key: "subscription15",
        value: function subscription15() {
          var api = "".concat(this.endpoint, "/subscription15/").concat(this.getCurrentUserId());
          return this.http.get(api);
        } // update myinfo for subscription 30

      }, {
        key: "subscription30",
        value: function subscription30() {
          var api = "".concat(this.endpoint, "/subscription30/").concat(this.getCurrentUserId());
          return this.http.get(api);
        } // get the block users

      }, {
        key: "getBlockUsers",
        value: function getBlockUsers() {
          var api = "".concat(this.endpoint, "/blockusers/").concat(this.getCurrentUserId());
          return this.http.get(api);
        } // confirm the user information

      }, {
        key: "confirmEmail",
        value: function confirmEmail(uemail) {
          var api = "".concat(this.endpoint, "/confirm/").concat(uemail);
          return this.http.get(api, {
            headers: this.headers
          }).subscribe(function (res) {
            console.log(res);
          });
        } // refresh the message

      }, {
        key: "messageRefresh",
        value: function messageRefresh(uid) {
          var api = "".concat(this.endpoint, "/refresh/").concat(uid);
          return this.http.get(api, {
            headers: this.headers
          }).subscribe(function (res) {
            console.log(res);
          });
        } // check user image upload state

      }, {
        key: "getUserimg",
        value: function getUserimg() {
          var api = "".concat(this.startpoint, "/getUserimg/").concat(this.currentUser.msg._id);
          return this.http.get(api);
        }
      }, {
        key: "isLoggedIn",
        get: function get() {
          var authToken = localStorage.getItem('access_token');
          return authToken !== null ? true : false;
        }
      }]);

      return AuthService;
    }();

    AuthService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AuthService);
    /***/
  },

  /***/
  "./src/app/shared/authconfig.interceptor.ts":
  /*!**************************************************!*\
    !*** ./src/app/shared/authconfig.interceptor.ts ***!
    \**************************************************/

  /*! exports provided: AuthInterceptor */

  /***/
  function srcAppSharedAuthconfigInterceptorTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthInterceptor", function () {
      return AuthInterceptor;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/shared/auth.service.ts");

    var AuthInterceptor =
    /*#__PURE__*/
    function () {
      function AuthInterceptor(authService) {
        _classCallCheck(this, AuthInterceptor);

        this.authService = authService;
      }

      _createClass(AuthInterceptor, [{
        key: "intercept",
        value: function intercept(req, next) {
          var authToken = this.authService.getToken();
          req = req.clone({
            setHeaders: {
              Authorization: "Bearer " + authToken
            }
          });
          return next.handle(req);
        }
      }]);

      return AuthInterceptor;
    }();

    AuthInterceptor.ctorParameters = function () {
      return [{
        type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }];
    };

    AuthInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], AuthInterceptor);
    /***/
  },

  /***/
  "./src/app/subscription/subscription.component.scss":
  /*!**********************************************************!*\
    !*** ./src/app/subscription/subscription.component.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSubscriptionSubscriptionComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N1YnNjcmlwdGlvbi9zdWJzY3JpcHRpb24uY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/subscription/subscription.component.ts":
  /*!********************************************************!*\
    !*** ./src/app/subscription/subscription.component.ts ***!
    \********************************************************/

  /*! exports provided: SubscriptionComponent */

  /***/
  function srcAppSubscriptionSubscriptionComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SubscriptionComponent", function () {
      return SubscriptionComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var SubscriptionComponent =
    /*#__PURE__*/
    function () {
      function SubscriptionComponent() {
        _classCallCheck(this, SubscriptionComponent);
      }

      _createClass(SubscriptionComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return SubscriptionComponent;
    }();

    SubscriptionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-subscription',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./subscription.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/subscription/subscription.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./subscription.component.scss */
      "./src/app/subscription/subscription.component.scss")).default]
    })], SubscriptionComponent);
    /***/
  },

  /***/
  "./src/app/update/update.component.scss":
  /*!**********************************************!*\
    !*** ./src/app/update/update.component.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppUpdateUpdateComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VwZGF0ZS91cGRhdGUuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/update/update.component.ts":
  /*!********************************************!*\
    !*** ./src/app/update/update.component.ts ***!
    \********************************************/

  /*! exports provided: UpdateComponent */

  /***/
  function srcAppUpdateUpdateComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UpdateComponent", function () {
      return UpdateComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var UpdateComponent =
    /*#__PURE__*/
    function () {
      function UpdateComponent() {
        _classCallCheck(this, UpdateComponent);
      }

      _createClass(UpdateComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return UpdateComponent;
    }();

    UpdateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-update',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./update.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/update/update.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./update.component.scss */
      "./src/app/update/update.component.scss")).default]
    })], UpdateComponent);
    /***/
  },

  /***/
  "./src/app/user-authentication/user-authentication.component.scss":
  /*!************************************************************************!*\
    !*** ./src/app/user-authentication/user-authentication.component.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUserAuthenticationUserAuthenticationComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "header {\n  position: relative;\n  background-color: #04af74 !important;\n  height: 100px;\n}\n\nimg {\n  height: 100%;\n  padding: 0;\n  margin: 0;\n}\n\nheader h1 {\n  position: absolute;\n  color: white;\n  font-size: 25px;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n}\n\n.row {\n  height: calc(100% - 100px);\n  width: 100%;\n  background-image: url('back_3.jpg');\n  background-repeat: no-repeat;\n  background-size: cover;\n  margin: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci1hdXRoZW50aWNhdGlvbi9FOlxccHJvamVjdHNcXE5vZGUrQW5ndWxhclxcZm9vdGJhbGwgYmV0dGluZyBzaXRlXFxmcm9udCBlbmQgb2ZmaSB3aWZiYWxsIDJcXGZyb250IGVuZC9zcmNcXGFwcFxcdXNlci1hdXRoZW50aWNhdGlvblxcdXNlci1hdXRoZW50aWNhdGlvbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvdXNlci1hdXRoZW50aWNhdGlvbi91c2VyLWF1dGhlbnRpY2F0aW9uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxvQ0FBQTtFQUNBLGFBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQ0VKOztBREFBO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0Esd0NBQUE7VUFBQSxnQ0FBQTtBQ0dKOztBRERBO0VBQ0ksMEJBQUE7RUFDQSxXQUFBO0VBQ0EsbUNBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtBQ0lKIiwiZmlsZSI6InNyYy9hcHAvdXNlci1hdXRoZW50aWNhdGlvbi91c2VyLWF1dGhlbnRpY2F0aW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaGVhZGVye1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDQsIDE3NSwgMTE2KSFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6MTAwcHg7XHJcbn1cclxuaW1ne1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5oZWFkZXIgaDF7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG59XHJcbi5yb3d7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDEwMHB4KTsgXHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvYmFja18zLmpwZycpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICBtYXJnaW46MHB4O1xyXG59XHJcbiIsImhlYWRlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzA0YWY3NCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG5pbWcge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMDtcbn1cblxuaGVhZGVyIGgxIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG5cbi5yb3cge1xuICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDEwMHB4KTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9iYWNrXzMuanBnXCIpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBtYXJnaW46IDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/user-authentication/user-authentication.component.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/user-authentication/user-authentication.component.ts ***!
    \**********************************************************************/

  /*! exports provided: UserAuthenticationComponent */

  /***/
  function srcAppUserAuthenticationUserAuthenticationComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserAuthenticationComponent", function () {
      return UserAuthenticationComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var UserAuthenticationComponent =
    /*#__PURE__*/
    function () {
      function UserAuthenticationComponent() {
        _classCallCheck(this, UserAuthenticationComponent);
      }

      _createClass(UserAuthenticationComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {// this.isLoading = true;
        }
      }]);

      return UserAuthenticationComponent;
    }();

    UserAuthenticationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-user-authentication',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./user-authentication.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/user-authentication/user-authentication.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./user-authentication.component.scss */
      "./src/app/user-authentication/user-authentication.component.scss")).default]
    })], UserAuthenticationComponent);
    /***/
  },

  /***/
  "./src/app/webchat.service.ts":
  /*!************************************!*\
    !*** ./src/app/webchat.service.ts ***!
    \************************************/

  /*! exports provided: WebchatService */

  /***/
  function srcAppWebchatServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WebchatService", function () {
      return WebchatService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var socket_io_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! socket.io-client */
    "./node_modules/socket.io-client/lib/index.js");
    /* harmony import */


    var socket_io_client__WEBPACK_IMPORTED_MODULE_2___default =
    /*#__PURE__*/
    __webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */


    var rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/Observable */
    "./node_modules/rxjs-compat/_esm2015/Observable.js");

    var WebchatService =
    /*#__PURE__*/
    function () {
      function WebchatService() {
        _classCallCheck(this, WebchatService);

        this.socket = socket_io_client__WEBPACK_IMPORTED_MODULE_2__('http://localhost:3000');
      } // send my online state


      _createClass(WebchatService, [{
        key: "iamonline",
        value: function iamonline(data) {
          this.socket.emit('iamonline', data);
        } // check the online counters

      }, {
        key: "onlineusers",
        value: function onlineusers() {
          var _this13 = this;

          var observable = new rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"](function (observer) {
            _this13.socket.on('onlinecounter', function (data) {
              observer.next(data);
            });

            return function () {
              _this13.socket.disconnect();
            };
          });
          return observable;
        } // logout and offline users

      }, {
        key: "offline",
        value: function offline(data) {
          this.socket.emit('iamoffline', data);
        } // sent message

      }, {
        key: "sendMessage",
        value: function sendMessage(data) {
          this.socket.emit('message', data);
        } // send answer

      }, {
        key: "sendAnswer",
        value: function sendAnswer(data) {
          this.socket.emit('answer', data);
        } // get new answer

      }, {
        key: "newAnswer",
        value: function newAnswer() {
          var _this14 = this;

          var observable = new rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"](function (observer) {
            _this14.socket.on('new answer', function (data) {
              observer.next(data);
            });

            return function () {
              _this14.socket.disconnect();
            };
          });
          return observable;
        } // get the message

      }, {
        key: "newMessageReceived",
        value: function newMessageReceived() {
          var _this15 = this;

          var observable = new rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"](function (observer) {
            _this15.socket.on('new message', function (data) {
              observer.next(data);
            });

            return function () {
              _this15.socket.disconnect();
            };
          });
          return observable;
        } // send the subscribe

      }, {
        key: "subscribePost",
        value: function subscribePost(data) {
          this.socket.emit('subscribePost', data);
        } // get the susbscribe

      }, {
        key: "newSubscribePost",
        value: function newSubscribePost() {
          var _this16 = this;

          var observable = new rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"](function (observer) {
            _this16.socket.on('new subscribePost', function (data) {
              observer.next(data);
            });

            return function () {
              _this16.socket.disconnect();
            };
          });
          return observable;
        } // send the unsubscbribe

      }, {
        key: "unsubscribePost",
        value: function unsubscribePost(data) {
          this.socket.emit('unsubscribePost', data);
        } // get the unsusbscribe

      }, {
        key: "newUnsubscribePost",
        value: function newUnsubscribePost() {
          var _this17 = this;

          var observable = new rxjs_Observable__WEBPACK_IMPORTED_MODULE_3__["Observable"](function (observer) {
            _this17.socket.on('new unsubscribePost', function (data) {
              observer.next(data);
            });

            return function () {
              _this17.socket.disconnect();
            };
          });
          return observable;
        } // blocking the user

      }, {
        key: "messageblock",
        value: function messageblock(data) {
          this.socket.emit('block message', data);
        } // unblocking the user

      }, {
        key: "messageunblock",
        value: function messageunblock(data) {
          this.socket.emit('unblock message', data);
        }
      }]);

      return WebchatService;
    }();

    WebchatService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], WebchatService);
    /***/
  },

  /***/
  "./src/app/wifpaypal/wifpaypal.component.scss":
  /*!****************************************************!*\
    !*** ./src/app/wifpaypal/wifpaypal.component.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppWifpaypalWifpaypalComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".cancel_button {\n  padding: 7px 18px;\n  background-color: lightcoral;\n  color: white;\n  border-radius: 8px;\n  border: none;\n}\n\n.back_franceimage {\n  background: url('pay15.jfif');\n  background-color: rgba(255, 255, 255, 0);\n  background-blend-mode: lighten;\n  height: 100%;\n  /* Center and scale the image nicely */\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvd2lmcGF5cGFsL0U6XFxwcm9qZWN0c1xcTm9kZStBbmd1bGFyXFxmb290YmFsbCBiZXR0aW5nIHNpdGVcXGZyb250IGVuZCBvZmZpIHdpZmJhbGwgMlxcZnJvbnQgZW5kL3NyY1xcYXBwXFx3aWZwYXlwYWxcXHdpZnBheXBhbC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvd2lmcGF5cGFsL3dpZnBheXBhbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0VBQ0EsNEJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDQ0o7O0FERUE7RUFDSSw2QkFBQTtFQUNBLHdDQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0Esc0NBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3dpZnBheXBhbC93aWZwYXlwYWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FuY2VsX2J1dHRvbiB7XG4gICAgcGFkZGluZzogN3B4IDE4cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRjb3JhbDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJvcmRlcjogbm9uZTtcbn1cblxuLmJhY2tfZnJhbmNlaW1hZ2Uge1xuICAgIGJhY2tncm91bmQ6IHVybCgnLi4vLi4vYXNzZXRzL3BheTE1LmpmaWYnKTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDApO1xuICAgIGJhY2tncm91bmQtYmxlbmQtbW9kZTogbGlnaHRlbjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgLyogQ2VudGVyIGFuZCBzY2FsZSB0aGUgaW1hZ2UgbmljZWx5ICovXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn0iLCIuY2FuY2VsX2J1dHRvbiB7XG4gIHBhZGRpbmc6IDdweCAxOHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGNvcmFsO1xuICBjb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4uYmFja19mcmFuY2VpbWFnZSB7XG4gIGJhY2tncm91bmQ6IHVybChcIi4uLy4uL2Fzc2V0cy9wYXkxNS5qZmlmXCIpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDApO1xuICBiYWNrZ3JvdW5kLWJsZW5kLW1vZGU6IGxpZ2h0ZW47XG4gIGhlaWdodDogMTAwJTtcbiAgLyogQ2VudGVyIGFuZCBzY2FsZSB0aGUgaW1hZ2UgbmljZWx5ICovXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/wifpaypal/wifpaypal.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/wifpaypal/wifpaypal.component.ts ***!
    \**************************************************/

  /*! exports provided: WifpaypalComponent */

  /***/
  function srcAppWifpaypalWifpaypalComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WifpaypalComponent", function () {
      return WifpaypalComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _shared_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../shared/auth.service */
    "./src/app/shared/auth.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var WifpaypalComponent =
    /*#__PURE__*/
    function () {
      function WifpaypalComponent(_location, authService, router) {
        _classCallCheck(this, WifpaypalComponent);

        this._location = _location;
        this.authService = authService;
        this.router = router;
        this.warning = false;
        this.warning_message = '';
        this.currentUser = JSON.parse(localStorage.getItem('current_user'));
        this.userId = String;
        this.showSuccess = false;
      }

      _createClass(WifpaypalComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.initConfig();
          this.currentUser = JSON.parse(localStorage.getItem('current_user'));
          this.userId = JSON.parse(localStorage.getItem('current_user')).msg._id;
          console.log(this.userId);
          console.log(this.currentUser);
        }
      }, {
        key: "initConfig",
        value: function initConfig() {
          var _this18 = this;

          this.payPalConfig = {
            currency: 'EUR',
            clientId: 'AQvRUFJmgSZrT--aRcEgO27QKgFh7qCD6WXwrmbNxyGWMpXaR_sUI6c6-trqdfIkyxiPjSHSTdpObpzv',
            createOrderOnClient: function createOrderOnClient(data) {
              return {
                intent: 'CAPTURE',
                purchase_units: [{
                  amount: {
                    currency_code: 'EUR',
                    value: '9.99',
                    breakdown: {
                      item_total: {
                        currency_code: 'EUR',
                        value: '9.99'
                      }
                    }
                  },
                  items: [{
                    name: 'Enterprise Subscription',
                    quantity: '1',
                    category: 'DIGITAL_GOODS',
                    unit_amount: {
                      currency_code: 'EUR',
                      value: '9.99'
                    }
                  }]
                }]
              };
            },
            advanced: {
              commit: 'false'
            },
            style: {
              label: 'paypal',
              size: 'small',
              shape: 'pill',
              color: 'blue',
              layout: 'horizontal',
              tagline: false
            },
            onApprove: function onApprove(data, actions) {
              _this18.warning = false;
              console.log('onApprove - transaction was approved, but not authorized', data, actions);
              actions.order.get().then(function (details) {
                console.log('onApprove - you can get full order details inside onApprove: ', details);
              });
            },
            onClientAuthorization: function onClientAuthorization(data) {
              console.log('onClientAuthorization - you should probably inform your server about completed transaction at this point', data);
              _this18.showSuccess = true;
              console.log(_this18.warning);
              _this18.warning_message = 'Congratelation!\nYou have the bonus from now!';
              console.log(_this18.warning_message);

              _this18.authService.subscription15().subscribe(function (data) {
                console.log(data);

                if (data == 'faild' || data == null) {} else {
                  var userdata = {
                    msg: data
                  };
                  localStorage.setItem('current_user', JSON.stringify(userdata));
                  _this18.warning = false; // this.ngZone.run(() => this.router.navigate(['main/' + this.userId])).then();
                }
              }); // this.router.navigate(['main/' + this.userId]);

            },
            onCancel: function onCancel(data, actions) {
              _this18.warning = false;
              console.log('OnCancel', data, actions);
            },
            onError: function onError(err) {
              _this18.warning = false;
              console.log('OnError', err);
            },
            onClick: function onClick(data, actions) {
              console.log('onClick', data, actions);
              _this18.warning = true;
              _this18.warning_message = 'Please wait "Wifball subscription verification and confirmation"'; // this.warning_message = '... please wait ...';
            }
          };
        }
      }, {
        key: "cancel",
        value: function cancel() {
          this._location.back();
        }
      }, {
        key: "confirm",
        value: function confirm() {
          // console.log(this.currentUser.msg._id);
          // this.router.navigate(['main/' + this.authService.getCurrentUser().msg._id]);
          this.warning_message = '';

          if (this.showSuccess) {
            this._location.back();
          }
        }
      }]);

      return WifpaypalComponent;
    }();

    WifpaypalComponent.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"]
      }, {
        type: _shared_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }];
    };

    WifpaypalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-wifpaypal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./wifpaypal.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/wifpaypal/wifpaypal.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./wifpaypal.component.scss */
      "./src/app/wifpaypal/wifpaypal.component.scss")).default]
    })], WifpaypalComponent);
    /***/
  },

  /***/
  "./src/app/wifpaypal30/wifpaypal30.component.scss":
  /*!********************************************************!*\
    !*** ./src/app/wifpaypal30/wifpaypal30.component.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppWifpaypal30Wifpaypal30ComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".cancel_button {\n  padding: 7px 18px;\n  background-color: lightcoral;\n  color: white;\n  border-radius: 8px;\n  border: none;\n}\n\n.back_franceimage {\n  background: url('worldcup2.jpg');\n  background-color: rgba(255, 255, 255, 0);\n  background-blend-mode: lighten;\n  height: 100%;\n  /* Center and scale the image nicely */\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n\n.paypal-button-clicked {\n  display: none !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvd2lmcGF5cGFsMzAvRTpcXHByb2plY3RzXFxOb2RlK0FuZ3VsYXJcXGZvb3RiYWxsIGJldHRpbmcgc2l0ZVxcZnJvbnQgZW5kIG9mZmkgd2lmYmFsbCAyXFxmcm9udCBlbmQvc3JjXFxhcHBcXHdpZnBheXBhbDMwXFx3aWZwYXlwYWwzMC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvd2lmcGF5cGFsMzAvd2lmcGF5cGFsMzAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0ksZ0NBQUE7RUFDQSx3Q0FBQTtFQUNBLDhCQUFBO0VBQ0EsWUFBQTtFQUNBLHNDQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FDQ0o7O0FERUE7RUFDSSx3QkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvd2lmcGF5cGFsMzAvd2lmcGF5cGFsMzAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FuY2VsX2J1dHRvbiB7XG4gICAgcGFkZGluZzogN3B4IDE4cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRjb3JhbDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJvcmRlcjogbm9uZTtcbn1cblxuLmJhY2tfZnJhbmNlaW1hZ2Uge1xuICAgIGJhY2tncm91bmQ6IHVybCgnLi4vLi4vYXNzZXRzL3dvcmxkY3VwMi5qcGcnKTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDApO1xuICAgIGJhY2tncm91bmQtYmxlbmQtbW9kZTogbGlnaHRlbjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgLyogQ2VudGVyIGFuZCBzY2FsZSB0aGUgaW1hZ2UgbmljZWx5ICovXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuLnBheXBhbC1idXR0b24tY2xpY2tlZCB7XG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xufSIsIi5jYW5jZWxfYnV0dG9uIHtcbiAgcGFkZGluZzogN3B4IDE4cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Y29yYWw7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5iYWNrX2ZyYW5jZWltYWdlIHtcbiAgYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL3dvcmxkY3VwMi5qcGdcIik7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMCk7XG4gIGJhY2tncm91bmQtYmxlbmQtbW9kZTogbGlnaHRlbjtcbiAgaGVpZ2h0OiAxMDAlO1xuICAvKiBDZW50ZXIgYW5kIHNjYWxlIHRoZSBpbWFnZSBuaWNlbHkgKi9cbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4ucGF5cGFsLWJ1dHRvbi1jbGlja2VkIHtcbiAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/wifpaypal30/wifpaypal30.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/wifpaypal30/wifpaypal30.component.ts ***!
    \******************************************************/

  /*! exports provided: Wifpaypal30Component */

  /***/
  function srcAppWifpaypal30Wifpaypal30ComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Wifpaypal30Component", function () {
      return Wifpaypal30Component;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _shared_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../shared/auth.service */
    "./src/app/shared/auth.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var Wifpaypal30Component =
    /*#__PURE__*/
    function () {
      function Wifpaypal30Component(_location, authService, router) {
        _classCallCheck(this, Wifpaypal30Component);

        this._location = _location;
        this.authService = authService;
        this.router = router;
        this.warning = false;
        this.warning_message = '';
        this.currentUser = JSON.parse(localStorage.getItem('current_user'));
        this.userId = String;
        this.showSuccess = false;
      }

      _createClass(Wifpaypal30Component, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.initConfig();
          this.currentUser = JSON.parse(localStorage.getItem('current_user'));
          this.userId = JSON.parse(localStorage.getItem('current_user')).msg._id;
          console.log(this.userId);
          console.log(this.currentUser);
        }
      }, {
        key: "initConfig",
        value: function initConfig() {
          var _this19 = this;

          this.payPalConfig = {
            currency: 'EUR',
            clientId: 'AQvRUFJmgSZrT--aRcEgO27QKgFh7qCD6WXwrmbNxyGWMpXaR_sUI6c6-trqdfIkyxiPjSHSTdpObpzv',
            createOrderOnClient: function createOrderOnClient(data) {
              return {
                intent: 'CAPTURE',
                purchase_units: [{
                  amount: {
                    currency_code: 'EUR',
                    value: '14.99',
                    breakdown: {
                      item_total: {
                        currency_code: 'EUR',
                        value: '14.99'
                      }
                    }
                  },
                  items: [{
                    name: 'Enterprise Subscription',
                    quantity: '1',
                    category: 'DIGITAL_GOODS',
                    unit_amount: {
                      currency_code: 'EUR',
                      value: '14.99'
                    }
                  }]
                }]
              };
            },
            advanced: {
              commit: 'false'
            },
            style: {
              label: 'pay',
              size: 'small',
              shape: 'pill',
              color: 'blue',
              layout: 'horizontal',
              tagline: false
            },
            onApprove: function onApprove(data, actions) {
              _this19.warning = false;
              console.log('onApprove - transaction was approved, but not authorized', data, actions);
              actions.order.get().then(function (details) {
                console.log('onApprove - you can get full order details inside onApprove: ', details);
              });
            },
            onClientAuthorization: function onClientAuthorization(data) {
              _this19.showSuccess = true;
              _this19.warning_message = 'Congratelation!\nYou have the bonus from now!';
              console.log('onClientAuthorization - you should probably inform your server about completed transaction at this point', data);

              _this19.authService.subscription30().subscribe(function (data) {
                console.log(data);

                if (data == 'faild' || data == null) {} else {
                  var userdata = {
                    msg: data
                  };
                  localStorage.setItem('current_user', JSON.stringify(userdata));
                  _this19.warning = false; // this.ngZone.run(() => this.router.navigate(['main/' + this.userId])).then();
                }
              });

              _this19.warning = false;
              console.log(_this19.warning_message);
            },
            onCancel: function onCancel(data, actions) {
              console.log('OnCancel', data, actions);
              _this19.warning = false;
            },
            onError: function onError(err) {
              _this19.warning = false;
              console.log('OnError', err);
            },
            onClick: function onClick(data, actions) {
              console.log('onClick', data, actions);
              _this19.warning = true;
              _this19.warning_message = 'Please wait "Wifball subscription verification and confirmation"';
            }
          };
        } // cancel and go to back

      }, {
        key: "cancel",
        value: function cancel() {
          this._location.back();
        }
      }, {
        key: "confirm",
        value: function confirm() {
          // console.log(this.currentUser.msg._id);
          // this.router.navigate(['main/' + this.authService.getCurrentUser().msg._id]);
          this.warning_message = '';

          if (this.showSuccess) {
            this._location.back();
          }
        }
      }]);

      return Wifpaypal30Component;
    }();

    Wifpaypal30Component.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"]
      }, {
        type: _shared_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }];
    };

    Wifpaypal30Component = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-wifpaypal30',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./wifpaypal30.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/wifpaypal30/wifpaypal30.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./wifpaypal30.component.scss */
      "./src/app/wifpaypal30/wifpaypal30.component.scss")).default]
    })], Wifpaypal30Component);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var hammerjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! hammerjs */
    "./node_modules/hammerjs/hammer.js");
    /* harmony import */


    var hammerjs__WEBPACK_IMPORTED_MODULE_1___default =
    /*#__PURE__*/
    __webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["enableProdMode"])();
    }

    if (!/localhost/.test(document.location.host)) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_4__["AppModule"]).catch(function (err) {
      return console.error(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! E:\projects\Node+Angular\football betting site\front end offi wifball 2\front end\src\main.ts */
    "./src/main.ts");
    /***/
  },

  /***/
  1:
  /*!********************!*\
    !*** ws (ignored) ***!
    \********************/

  /*! no static exports found */

  /***/
  function _(module, exports) {
    /* (ignored) */

    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map